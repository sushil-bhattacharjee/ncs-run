# -*- mode: python; python-indent: 4 -*-
from . import rm_alloc

def net_request(service, svc_xpath, username, pool_name, allocation_name, cidrmask,
                invert_cidr=False, redeploy_type="default", sync=False, root=None):
    """Create an allocation request.

    After calling this function, you have to call net_ready
    to check the availability of the allocated network.

    NOTE: Don't forget to add IP allocator as a required package
          in your package-meta-data.xml:
          <required-package>
             <name>ipaddress-allocator</name>
          </required-package>

    Example:

    import resource_manager.ipaddress_allocator as ip_allocator
    pool_name = "The Pool"
    allocation_name = "Unique allocation name"

    # This will try to allocate the network of size 24 from the pool named 'The Pool'
    # using allocation name: 'Unique allocation name'
    ip_allocator.net_request(service,
                             "/services/vl:loop-python[name='%s']" % (service.name),
                             tctx.username,
                             pool_name,
                             allocation_name,
                             24)


    net = ip_allocator.net_read(tctx.username, root,
                               pool_name, allocation_name)

    if not net:
        self.log.info("Alloc not ready")
        return

    print ("net = %s" % (net))

    The redeploy_type argument sets the redeploy type used by the Resource
    Manager to redeploy the service. The allowed values:
    - touch
    - re-deploy
    - reactive-re-deploy
    - default: chooses one of the previous options based on the NSO version.

    Arguments:
    service -- the requesting service node
    svc_xpath -- xpath to the requesting service
    username -- username to use when redeploying the requesting service
    pool_name -- name of pool to request from
    allocation_name -- unique allocation name
    cidrmask -- the size of the network
    invert_cidr -- invert the cidrmask
    redeploy_type -- service redeploy action: default, touch, re-deploy, reactive-re-deploy
    sync -- synchronous allocation. Default is asynchronous.
    root -- root node, mandatory if sync=True
    """
    try:
        if sync:
            rm_alloc.net_request_sync(root, service, username, pool_name, allocation_name, cidrmask,
                                      invert_cidr)
        rm_alloc.net_request_async(service, svc_xpath, username, pool_name, allocation_name,
                                   cidrmask, invert_cidr, redeploy_type, sync)
    except Exception:
        raise


def net_request_static(service, svc_xpath, username,
                pool_name, allocation_name, subnet_start_ip, cidrmask,
                invert_cidr=False, redeploy_type="default", sync=False, root=None):
    """Create a static allocation request.

    After calling this function, you have to call net_ready
    to check the availability of the allocated network.

    NOTE: Don't forget to add IP allocator as a required package
          in your package-meta-data.xml:
          <required-package>
             <name>ipaddress-allocator</name>
          </required-package>

    Example:

    import resource_manager.ipaddress_allocator as ip_allocator
    pool_name = "The Pool"
    allocation_name = "Unique allocation name"

    # This will try to allocate the address 10.0.0.8 from the pool named 'The Pool'
    # using allocation name: 'Unique allocation name'
    ip_allocator.net_request_static(service,
                             "/services/vl:loop-python[name='%s']" % (service.name),
                             tctx.username,
                             pool_name,
                             allocation_name,
                             "10.0.0.8"
                             32)


    net = ip_allocator.net_read(tctx.username, root,
                               pool_name, allocation_name)

    if not net:
        self.log.info("Alloc not ready")
        return

    print ("net = %s" % (net))

    The redeploy_type argument sets the redeploy type used by the Resource
    Manager to redeploy the service. The allowed values:
    - touch
    - re-deploy
    - reactive-re-deploy
    - default: chooses one of the previous options based on the NSO version.

    Arguments:
    service -- the requesting service node
    svc_xpath -- xpath to the requesting service
    username -- username to use when redeploying the requesting service
    pool_name -- name of pool to request from
    allocation_name -- unique allocation name
    subnet_start_ip -- starting ip address of the requested subnet
    cidrmask -- the size of the network
    invert_cidr -- invert the cidrmask
    redeploy_type -- service redeploy action: default, touch, re-deploy, reactive-re-deploy
    sync -- synchronous allocation. Default is asynchronous.
    root -- root node, mandatory if sync=True
    """
    try:
        if sync:
            rm_alloc.net_request_sync(root, service, username, pool_name, allocation_name, cidrmask,
                                      invert_cidr, subnet_start_ip)
        rm_alloc.net_request_async(service, svc_xpath, username, pool_name, allocation_name,
                                   cidrmask, invert_cidr, redeploy_type, sync, subnet_start_ip)
    except Exception:
        raise


def net_read(username, root, pool_name, allocation_name):
    """Returns the allocated network or None

    Arguments:
    username -- the requesting service's transaction's user
    root -- a maagic root for the current transaction
    pool_name -- name of pool to request from
    allocation_name -- unique allocation name
    """
    # sync flow should receive response subnet in current transaction 
    # otherwise commit will get aborted with exception/failure error
    return rm_alloc.net_read(username, root, pool_name, allocation_name)

