package com.tailf.pkg.idallocator;

import java.io.IOException;
import java.net.SocketException;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.log4j.Logger;
import com.tailf.cdb.Cdb;
import com.tailf.cdb.CdbDiffIterate;
import com.tailf.cdb.CdbSubscription;
import com.tailf.cdb.CdbSubscriptionSyncType;
import com.tailf.cdb.CdbSubscriptionType;
import com.tailf.conf.Conf;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfKey;
import com.tailf.conf.ConfList;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfObjectRef;
import com.tailf.conf.ConfPath;
import com.tailf.conf.DiffIterateFlags;
import com.tailf.conf.DiffIterateOperFlag;
import com.tailf.conf.DiffIterateResultFlag;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.ncs.ApplicationComponent;
import com.tailf.ncs.annotations.Resource;
import com.tailf.ncs.annotations.ResourceType;
import com.tailf.ncs.annotations.Scope;
import com.tailf.pkg.idallocator.namespaces.idAllocator;
import com.tailf.pkg.nsoutil.NSOUtil;
import com.tailf.pkg.nsoutil.ToRedeploy;
import com.tailf.pkg.resourcemanager.namespaces.resourceAllocator;

public class IDAllocRespReWriter implements ApplicationComponent, CdbDiffIterate {
    private static final Logger LOGGER = Logger.getLogger(IDAllocRespReWriter.class);

    @Resource(type = ResourceType.CDB, scope = Scope.INSTANCE,
        qualifier = "id-alloc-resp-re-writer-subscriber")
    private Cdb cdb;

    @Resource(type = ResourceType.MAAPI, scope = Scope.INSTANCE,
        qualifier = "id-alloc-resp-re-writer-m")
    private Maapi maapi;
    private int tid;

    private CdbSubscription sub = null;

    private Set<String> allocs;

    @Override
    public void init() throws Exception {
        maapi.startUserSession("admin", maapi.getSocket().getInetAddress(), "system", new String[] {
            "admin"}, MaapiUserSessionFlag.PROTO_TCP);
        tid = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);
        sub = cdb.newSubscription();
        sub.subscribe(CdbSubscriptionType.SUB_OPERATIONAL, 1, new resourceAllocator(), "/"
            + resourceAllocator.prefix + ":" + resourceAllocator._resource_pools_ + "/"
            + idAllocator.prefix + ":" + idAllocator._id_pool_ + "/"
            + idAllocator._allocation_ + "/" + idAllocator._response_ + "/"
            + idAllocator._id_);
 
        sub.subscribeDone();
        allocs = new HashSet<>();
        LOGGER.info("IDAllocRespReWriter subscription done");
    }

    @Override
    public void finish() throws Exception {
        try {
            allocs = null;
            cdb.close();
            maapi.finishTrans(tid);
            maapi.getSocket().close();
        } catch (Exception igone) {
        }
    }

    @Override
    public void run() {
        LOGGER.info("IDAllocRespReWriter Running...");
        while (true) {
            int[] points;
            try {
                points = sub.read();
            } catch (SocketException e) {
                LOGGER.warn(e.getMessage());
                return;
            } catch (Exception e) {
                LOGGER.error("Subscription read error", e);
                return;
            }
        
            try {
                if (NSOUtil.isHaEnabled(maapi, tid) && !NSOUtil.isPrimary(maapi, tid)) {
                    LOGGER.info("This node is not the primary node, it should sync.");
                    sub.sync(CdbSubscriptionSyncType.DONE_PRIORITY);
                    continue;
                }
            } catch (Exception e) {
                LOGGER.error("Failed reading HA mode:", e);
            }

            EnumSet<DiffIterateFlags> enumSet = EnumSet.<DiffIterateFlags>of(
                DiffIterateFlags.ITER_WANT_ANCESTOR_DELETE);
            Set<ToRedeploy> redeps = new HashSet<>();
            ExecutorService executor = Executors.newSingleThreadExecutor();
            try {
                sub.diffIterate(points[0], this, enumSet, redeps);
                if (!redeps.isEmpty()) {
                    ReWriter reWriter = new ReWriter(redeps);
                    executor.execute(reWriter);
                }
            } catch (Exception e) {
                LOGGER.error("", e);
            } finally {
                executor.shutdown();
                try {
                    sub.sync(CdbSubscriptionSyncType.DONE_PRIORITY);
                } catch (ConfException | IOException e) {
                    LOGGER.error("", e);
                }
            }
        }
    }

    @Override
    public DiffIterateResultFlag iterate(ConfObject[] kp, DiffIterateOperFlag op,
        ConfObject oldValue, ConfObject newValue, Object initstate) {
    	LOGGER.debug("iterate op = "+op+ " kp = "+ Conf.kpToString(kp));
        try {
            if (DiffIterateOperFlag.MOP_DELETED == op && kp.length == 7) {              	               	
                    @SuppressWarnings("unchecked")
                    HashSet<ToRedeploy> redeps = (HashSet<ToRedeploy>) initstate;
                    ConfObject[] newKp = Arrays.copyOfRange(kp, 2, kp.length);
                    String alloc = ((ConfKey) newKp[0]).elementAt(0).toString();
                    LOGGER.debug("allocation =  " + alloc);
                    if (Conf.kpToString(kp).contains(idAllocator._response_)) {
                        LOGGER.warn("Response got deleted for existing ID allocation: " + alloc);
                        
                        ConfPath requestp = new ConfPath(newKp);
                        String owner = null;
                        String allocatingService = requestp + "/"
                            + idAllocator._allocating_service_;

                        LOGGER.debug("allocatingService exist "+ maapi.exists(tid, allocatingService));
                        if (maapi.exists(tid, allocatingService)) {
                            ConfList v = (ConfList) maapi.getElem(tid, allocatingService);
                            ConfObjectRef objRef = (ConfObjectRef) v.get(0);
                            owner = new ConfPath(objRef.getElems()).toString();
                        }

                        if (null != owner) {
                            boolean syncFlow = maapi.exists(tid, requestp + "/"
                                + idAllocator._sync_alloc_);
                            LOGGER.debug("syncFlow = " + syncFlow);
                            if (syncFlow) {
                                String username = maapi.getElem(tid, requestp + "/"
                                    + idAllocator._username_).toString();
                                ToRedeploy redep = new ToRedeploy(owner, username);
                                LOGGER.warn("To re-write the response, re-deploying service: "
                                    + redep.getAllocatingService());
                                redeps.add(redep);
                            }
                        }
                    }
                } 
        } catch (Exception e) {
            LOGGER.error("", e);
        }
        return DiffIterateResultFlag.ITER_CONTINUE;
    }

    private class ReWriter implements Runnable {
        private Set<ToRedeploy> redeps;

        public ReWriter(Set<ToRedeploy> redeps) {
            super();
            this.redeps = redeps;
        }

        @Override
        public void run() {
            NSOUtil.redeploy(this.redeps);
        }

    }
}
