package com.example.vlan;

import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.tailf.conf.Conf;
import com.tailf.conf.ConfIPPrefix;
import com.tailf.conf.ConfXMLParam;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.annotations.ServiceCallback;
import com.tailf.dp.proto.ServiceCBType;
import com.tailf.dp.services.ServiceContext;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.navu.NavuException;
import com.tailf.navu.NavuNode;
import com.tailf.ncs.template.Template;
import com.tailf.ncs.template.TemplateVariables;
import com.tailf.pkg.ipaddressallocator.IPAddressAllocator;
import com.tailf.pkg.resourcemanager.RedeployType;


public class vlanRFS2 {
    private static Logger logger = LogManager.getLogger(vlanRFS2.class);


    /**
     * Create callback method. This method is called when a service instance committed due to a
     * create or update event.
     *
     * This method returns a opaque as a Properties object that can be null. If not null it is
     * stored persistently by Ncs. This object is then delivered as argument to new calls of the
     * create method for this service (fastmap algorithm). This way the user can store and later
     * modify persistent data outside the service model that might be needed.
     *
     * @param context - The current ServiceContext object
     * @param service - The NavuNode references the service node.
     * @param ncsRoot - This NavuNode references the ncs root.
     * @param opaque - Parameter contains a Properties object. This object may be used to transfer
     *        additional information between consecutive calls to the create callback. It is always
     *        null in the first call. I.e. when the service is first created.
     * @return Properties the returning opaque instance
     * @throws DpCallbackException
     */

    @ServiceCallback(servicePoint = "allocating-service-java-async-servicepoint",
        callType = ServiceCBType.CREATE)
    public Properties create(ServiceContext context, NavuNode service, NavuNode ncsRoot,
        Properties opaque) throws DpCallbackException {


        logger.info("vlanRFS2 -----create()");

        try {
            String srvcname = service.leaf("name").valueAsString();
            String pool = service.leaf("pool").valueAsString();
            String allocid = service.leaf("ipv4").valueAsString();
            String subsize = service.leaf("subnet-size").valueAsString();
            // String dev = service.leaf("device").valueAsString();

            IPAddressAllocator.subnetRequest(context, service, pool, "admin",
            		Integer.parseInt(subsize), allocid);
            boolean ready = IPAddressAllocator.responseReady(service.context(), pool, allocid);
            logger.info("vlanRFS2 -----create() ready " + ready);
            if (ready) {
                ConfIPPrefix ipvalue = IPAddressAllocator.subnetRead(service.context(), pool,
                    allocid);
                logger.info("vlanRFS2 -----create() ipvalue " + ipvalue.toString());
                Template vlanTemplate = new Template(context, "ip-allocated");
                TemplateVariables vlanVar = new TemplateVariables();
                vlanVar.putQuoted("ALLOCATED", ipvalue.toString());
                vlanVar.putQuoted("OWNER", service.getKeyPath());
                vlanTemplate.apply(service, vlanVar);
            }
        } catch (Exception e) {
            throw new DpCallbackException("Cannot create service ", e);
        }
        return opaque;
    }
}
