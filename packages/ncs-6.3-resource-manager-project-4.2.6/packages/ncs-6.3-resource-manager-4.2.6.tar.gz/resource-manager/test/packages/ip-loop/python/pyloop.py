import _ncs
import ncs
import _ncs.cdb as cdb
from ncs.application import Service
import resource_manager.ipaddress_allocator as ip_allocator
import socket


class LoopService(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')
        pool_name = service.pool
        alloc_name = service.allocation_name if service.allocation_name else service.name
        self.log.info('CIDR length = ', service.cidr_length)

        # Update deploys oper data count
        sock = socket.socket()
        cdb.connect(sock, type=cdb.DATA_SOCKET, ip='127.0.0.1', port=_ncs.NCS_PORT)
        cdb.start_session(sock, db=cdb.OPERATIONAL)
        deploy_path = "/services/ip-loop-python{{{}}}/deploys".format(service.name)
        deploys  = 1

        if cdb.exists(sock, deploy_path):
            deploys = cdb.get(sock, deploy_path).as_pyval()

        # Wont exist during first deployment
        if cdb.exists(sock, service._path):
            cdb.set_elem(sock, str(deploys + 1), deploy_path)

        cdb.end_session(sock)
        cdb.close(sock)

        # allocate resource
        ip_allocator.net_request(service,
                                 "/services/ip-vl:ip-loop-python[name='%s']" % (service.name),
                                 tctx.username,
                                 pool_name,
                                 alloc_name,
                                 service.cidr_length)

        net = ip_allocator.net_read(tctx.username, root,
                                    pool_name, alloc_name)
        if not net:
            self.log.info("Alloc not ready")
            return
        self.log.info('net = %s' % (net))


class Loop(ncs.application.Application):
    def setup(self):
        self.log.info('Loop RUNNING')
        self.register_service('ip-loopspnt-python', LoopService)

    def teardown(self):
        self.log.info('Loop FINISHED')
