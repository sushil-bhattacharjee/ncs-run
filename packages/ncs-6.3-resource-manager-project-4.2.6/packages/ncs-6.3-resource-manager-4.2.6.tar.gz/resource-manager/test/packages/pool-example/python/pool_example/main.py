# -*- mode: python; python-indent: 4 -*-
import ncs
import _ncs
import ncs.maapi as maapi
import ncs.maagic as maagic
from ncs.application import Service
import resource_manager.ipaddress_allocator as ip_allocator




# ------------------------
# SERVICE CALLBACK EXAMPLE
# ------------------------
class AllocateCallbacks(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('AllocateCallbacks create(service=', service._path, ')')
        self.log.info('requested allocation from {}'.format(service.pool))
        service_xpath = ("/allocating-service-py:allocating-service-py[name='{}']")
        ip_allocator.net_request(service,
                                 service_xpath.format(service.name),
                                 "admin",
                                 service.pool,
                                 service.ipv4,
                                 service.subnet_size, False, "default", True, root)

        # Check
        net = ip_allocator.net_read("admin", root, service.pool, service.ipv4)
        self.log.info('Check n/w create(IP=', net, ')')

        if net:
            self.log.info('received ip-address {} from {}'.format(str(net), service.pool))
            template = ncs.template.Template(service)
            vars = ncs.template.Variables()
            vars.add("ALLOCATED", str(net))
            vars.add("OWNER", service._path)
            template.apply('ip-allocated', vars)

            # template = ncs.template.Template(service)
            # vars = ncs.template.Variables()
            # vars.add("SERVICE", str(service.ipv4))
            # vars.add("DEVICE_NAME", str(service.device))
            # vars.add("IP", str(net))
            # template.apply('device', vars)

class AllocateCallbacksAsync(Service):

    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('AllocateCallbacksAsync create(service=', service._path, ')')
        self.log.info('requested allocation from {}'.format(service.pool))
        service_xpath = ("/allocating-service-async:allocating-service-async[name='{}']")
        ip_allocator.net_request(service,
                                 service_xpath.format(service.name),
                                 tctx.username,
                                 service.pool,
                                 service.ipv4,
                                 service.subnet_size,
                                 redeploy_type="re-deploy")
        # Check
        net = ip_allocator.net_read(tctx.username, root, service.pool, service.ipv4)
        self.log.info('Check n/w create(IP=', net, ')')

        if net:
            self.log.info('received ip-address {} from {}'.format(str(net), service.pool))
            template = ncs.template.Template(service)
            vars = ncs.template.Variables()
            vars.add("ALLOCATED", str(net))
            vars.add("OWNER", service._path)
            template.apply('ip-allocated', vars)
            # template = ncs.template.Template(service)
            # vars = ncs.template.Variables()
            # vars.add("SERVICE", str(service.ipv4))
            # vars.add("DEVICE_NAME", str(service.device))
            # vars.add("IP", str(net))
            # template.apply('device', vars)
# ---------------------------------------------
# COMPONENT THREAD THAT WILL BE STARTED BY NCS.
# ---------------------------------------------
class Main(ncs.application.Application):
    def setup(self):
        # The application class sets up logging for us. It is accessible
        # through 'self.log' and is a ncs.log.Log instance.
        self.log.info('Main RUNNING')

        # Service callbacks require a registration for a 'service point',
        # as specified in the corresponding data model.
        #
        self.register_service('allocating-service-servicepoint-py', AllocateCallbacks)
        self.register_service('allocating-service-async-servicepoint', AllocateCallbacksAsync)
        self.log.info('Main REGISTERED')

        # If we registered any callback(s) above, the Application class
        # took care of creating a daemon (related to the service/action point).

        # When this setup method is finished, all registrations are
        # considered done and the application is 'started'.

    def teardown(self):
        # When the application is finished (which would happen if NCS went
        # down, packages were reloaded or some error occurred) this teardown
        # method will be called.

        self.log.info('Main FINISHED')
