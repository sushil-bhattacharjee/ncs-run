/* Author: Johan Bevemyr <jbevemyr@cisco.com> */

package com.tailf.pkg.resourcemanager;

/* This module is empty for a reason.

Resource manager's functionality is realized in
an id-allocator and an ipaddress-allocator.

*/

public class ResourceAllocator {

}
