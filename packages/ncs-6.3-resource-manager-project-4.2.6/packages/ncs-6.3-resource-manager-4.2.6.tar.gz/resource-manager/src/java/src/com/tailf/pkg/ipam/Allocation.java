package com.tailf.pkg.ipam;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Allocation implements Serializable {
    private static final long serialVersionUID = -7671139904147340643L;
    private static final String RESOURCE_TYPE =
        "entity.resourcepool.resource.allocation";

    private String uuid;
    private String etype;
    private Subnet allocated;
    private List<String> occupants;
    private String username;
    private String requestId;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getEtype() {
        return etype;
    }

    public void setEtype(String etype) {
        this.etype = etype;
    }

    public Allocation() {}

    public Allocation(Subnet allocated, List<String> occupants, String username, String requestId) {
        this.allocated = allocated;
        this.occupants = occupants;
        this.username = username;
        this.requestId = requestId;
        this.etype = RESOURCE_TYPE;
    }

    public Allocation(Allocation that) {
        super();
        this.allocated = new Subnet(that.allocated);
		this.occupants = that.occupants;
        this.username = that.username;
        this.requestId = that.requestId;
        this.etype = RESOURCE_TYPE;
    }

    public Subnet getAllocated() {
        return allocated;
    }

    public void setAllocated(Subnet allocated) {
        this.allocated = allocated;
    }

    public List<String> getOccupants() {
        return occupants;
    }

    public String getUsername() {
        return username;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setOccupants(List<String> occupants) {
        this.occupants = occupants;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return String.format("{\"allocated\": %s, \"occupants\": %s," +
                             " \"username\": %s, \"requestId\": %s}",
                             allocated, occupants, username, requestId);
    }

	@Override
	public int hashCode() {
		return Objects.hash(allocated, requestId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
            return true;
        }
		if (obj == null) {
            return false;
        }
		if (getClass() != obj.getClass()) {
            return false;
        }
		Allocation other = (Allocation) obj;
		return Objects.equals(allocated, other.allocated)
				&& Objects.equals(requestId, other.requestId);
	}
}
