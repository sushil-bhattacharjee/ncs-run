/* Author: Johan Bevemyr <jbevemyr@cisco.com> */

package com.tailf.pkg.loop;

import java.util.Properties;
import org.apache.log4j.Logger;
import com.tailf.pkg.loop.namespaces.ipLoopService;
import com.tailf.pkg.resourcemanager.ResourceAllocator;
import com.tailf.pkg.resourcemanager.ResourceErrorException;
import com.tailf.pkg.resourcemanager.ResourceWaitException;
import com.tailf.pkg.resourcemanager.namespaces.*;
import com.tailf.pkg.ipaddressallocator.IPAddressAllocator;
import com.tailf.dp.DpActionTrans;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.annotations.ActionCallback;
import com.tailf.dp.annotations.ServiceCallback;
import com.tailf.dp.proto.ActionCBType;
import com.tailf.dp.proto.ServiceCBType;
import com.tailf.dp.services.ServiceContext;
import com.tailf.navu.*;
import com.tailf.cdb.*;
import com.tailf.maapi.*;
import com.tailf.conf.*;
import com.tailf.ncs.ns.Ncs;
import com.tailf.ncs.ResourceManager;
import com.tailf.ncs.annotations.Resource;
import com.tailf.ncs.annotations.ResourceType;
import com.tailf.ncs.annotations.Scope;

/**
 * This class implement the create logic for the Loop Service.
 *
 * The example will show how to use the resource allocator to allocate
 * an ip address, wait for it to become ready and then perform the
 * configuraton changes
 *
 *
 */

public class LoopServiceRFS {

    private static Logger LOGGER = Logger.getLogger(LoopServiceRFS.class);

    @Resource(type=ResourceType.CDB, scope=Scope.CONTEXT, qualifier="reactive")
    public Cdb cdb;
    public CdbSession cdbSess;

    /**
     * Create callback method.
     * This method is called when a service instance committed due to a create
     * or update event.
     *
     * This method returns a opaque as a Properties object that can be loop.
     * If not loop it is stored persistently by Ncs.
     * This object is then delivered as argument to new calls of the create
     * method for this service (fastmap algorithm).
     * This way the user can store and later modify persistent data outside
     * the service model that might be needed.
     *
     * @param context - The current ServiceContext object
     * @param service - The NavuNode references the service node.
     * @param root    - This NavuNode references the ncs root.
     * @param opaque  - Parameter contains a Properties object.
     *                  This object may be used to transfer
     *                  additional information between consecutive
     *                  calls to the create callback.  It is always
     *                  loop in the first call. I.e. when the service
     *                  is first created.
     * @return Properties the returning opaque instance
     * @throws DpCallbackException
     */
    @ServiceCallback(servicePoint = "ip-loopspnt",
        callType = ServiceCBType.CREATE)
    public Properties create(ServiceContext context,
                             NavuNode service,
                             NavuNode root,
                             Properties opaque) throws DpCallbackException {

        NavuContainer cdbroot = null;

        try {
            CdbSession sess = cdb.startSession(CdbDBType.CDB_OPERATIONAL);

            // Get the container at keypath
            // /services/loop{s1}
            NavuContainer loop = (NavuContainer) service;

            ConfBuf devName = (ConfBuf) loop.leaf("device").value();
            String poolName = loop.leaf("pool").value().toString();
            String allocationName = loop.leaf("name").value().toString();
            String servicePath = loop.getKeyPath();
            String deployPath = servicePath + "/deploys";
            int deploys = 1;

            if (loop.leaf("allocation-name").exists()) {
                allocationName = loop.leaf("allocation-name").value().toString();
            }

            if (sess.exists(deployPath)) {
                deploys = (int)((ConfUInt8)sess.getElem(deployPath)).longValue();
            }
            if (sess.exists(servicePath)) { // Will not exist the first time
                sess.setElem(new ConfUInt8(deploys + 1), deployPath);
            }
            sess.endSession();

            // Create resource allocation request
            LOGGER.debug(String.format("Requesting %s.", poolName));
            IPAddressAllocator.subnetRequest(service, poolName, "admin", 32, allocationName);

            try {
                // Check if resource has been allocated, the allocated
                // subnet will be returned from the function and we can
                // get it from net in this case.
                if (IPAddressAllocator.responseReady(loop.context(), cdb, poolName, allocationName)) {
                    ConfIPPrefix net =
                        IPAddressAllocator.subnetRead(cdb, poolName, allocationName);

                    ConfIPPrefix from =
                        IPAddressAllocator.fromRead(cdb, poolName, allocationName);

                    LOGGER.info("We got the address: " + net.getAddress() +
                                "/" + net.getMaskLength() + " " +
                                "From subnet: " + from.getAddress() +
                                "/" + from.getMaskLength());

                    // now read out some other dummy parameter in our service
                    ConfBuf unit = (ConfBuf) loop.leaf("unit").value();

                    // create some dummy config
                    root.container("ncs","devices").
                        list("device").
                        elem(new ConfKey(devName)).
                        container("config").
                        container("ios","interface").list("Loopback").
                        sharedCreate(new ConfKey(unit)).
                        leaf("description").set(net.getAddress().toString());
                }
            } catch (ResourceWaitException e) {
                // done, wait for re-deploy
                ;
            } catch (ResourceErrorException e) {
                // error
                LOGGER.error("Allocation failed", e);
            }

        } catch (Exception e) {
            throw new DpCallbackException("Could not instantiate service", e);
        } finally {
            try {
                if (cdbroot != null)
                    cdbroot.stopCdbSession();
            }
            catch (Exception ignore) {
            }
        }
        return opaque;
    }
}
