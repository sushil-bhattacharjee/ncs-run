import ncs
import ncs.maapi as maapi
from ncs.maapi import CommitParams
import ncs.maagic as maagic


def net_request_async(service, svc_xpath, username, pool_name, allocation_name, cidrmask,
                       invert_cidr=False, redeploy_type="default", sync=False, start_ip=None):
    # create rm allocation request as per the inputs
    # SYNC flag will help subscriber to execute appropriate logic
    template = ncs.template.Template(service)
    variables = ncs.template.Variables()
    variables.add("POOL", pool_name)
    variables.add("ALLOCATIONID", allocation_name)
    variables.add("USERNAME", username)
    variables.add("SERVICE", svc_xpath)
    variables.add("REDEPLOY_TYPE", redeploy_type)
    variables.add("SUBNET_START_IP", start_ip if start_ip else "")
    variables.add("SUBNET_SIZE", cidrmask)
    variables.add("INVERT", "true" if invert_cidr else "")
    variables.add("SYNC", "true" if sync else "")
    template.apply('resource-manager-ipaddress-allocation', variables)

def net_request_sync(root, service, username, pool_name, allocation_name, cidrmask,
                     invert_cidr=False, start_ip=None):
    if root is None:
        raise Exception(
            "root node is required in API argument for synchronous ip-address allocation request.")

    is_dry_run = CommitParams(maagic.get_trans(root).get_trans_params()).is_dry_run()
    internal_action = maagic.get_node(maagic.get_trans(root), "/ralloc:rm-action/sync-alloc")
    internal_action_input = internal_action.get_input()
    internal_action_input.pool = pool_name
    internal_action_input.allocid = allocation_name
    internal_action_input.user = username
    internal_action_input.cidrmask = cidrmask
    internal_action_input.invertcidr = invert_cidr
    internal_action_input.owner = service._path
    if start_ip:
        internal_action_input.subnetstartip = start_ip
    internal_action_input.dryrun = is_dry_run
    internal_action_output = internal_action(internal_action_input)

    if internal_action_output.allocated and "Error" in internal_action_output.allocated:
        raise Exception(internal_action_output.allocated)

    variables = ncs.template.Variables()
    variables.add('POOL', pool_name)
    variables.add('DRYRUN', "true" if is_dry_run else "")
    variables.add('ALLOCATIONID', allocation_name)
    variables.add('ALLOCIP', internal_action_output.allocated)
    variables.add('SUBNETIP', internal_action_output.subnet)
    template = ncs.template.Template(service)
    template.apply('resource-manager-ipaddress-allocation-response', variables)

def net_read(username, root, pool_name, allocation_name):
    # Look in the current transaction
    ip_pool_l = root.ralloc__resource_pools.ipalloc__ip_address_pool

    if pool_name not in ip_pool_l:
        raise LookupError("IP pool %s does not exist" % (pool_name))

    ip_pool = ip_pool_l[pool_name]

    if allocation_name not in ip_pool.allocation:
        raise LookupError("allocation %s does not exist in pool %s" %
                          (allocation_name, pool_name))

    alloc = ip_pool.allocation[allocation_name]
    if alloc.response and alloc.response.subnet:
        return alloc.response.subnet
    else:
        # Check allocation response from operational data
        with maapi.single_read_trans(username, "system",
                                     db=ncs.OPERATIONAL) as th:
            ip_pool_l = maagic.get_root(th).ralloc__resource_pools.ipalloc__ip_address_pool
    
            if pool_name not in ip_pool_l:
                return None
    
            ip_pool = ip_pool_l[pool_name]
            if allocation_name in ip_pool.allocation:
                alloc = ip_pool.allocation[allocation_name]
                if alloc.response.subnet:
                    return alloc.response.subnet
                elif alloc.response.error:
                    raise LookupError(alloc.response.error)
            else:
                return None
            