package com.tailf.pkg.nsoutil;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.tailf.conf.Conf;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfObjectRef;
import com.tailf.conf.ConfPath;
import com.tailf.conf.ConfUInt32;
import com.tailf.conf.ConfValue;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.navu.NavuContainer;
import com.tailf.navu.NavuContext;
import com.tailf.navu.NavuException;
import com.tailf.navu.NavuLeafList;
import com.tailf.navu.NavuList;
import com.tailf.pkg.idallocator.IdAllocator;
import com.tailf.pkg.idallocator.IdAllocator.Pool;
import com.tailf.pkg.idallocator.namespaces.idAllocator;
import com.tailf.pkg.idpool.Allocation;
import com.tailf.pkg.idpool.IDPool;
import com.tailf.pkg.idpool.exceptions.AllocationException;
import com.tailf.pkg.ipaddressallocator.IPAddressAllocator;
import com.tailf.pkg.resourcemanager.ResourceErrorException;
import com.tailf.pkg.resourcemanager.namespaces.resourceAllocator;

public class NSOTools {
    private static final Logger LOGGER = Logger.getLogger(NSOTools.class);

	/*
	 * """ upgrade script for resource-manager from 3.5.6(or any version <4.0.0) to
	 * version 4.0.0 or above This upgrade script is configured in the
	 * package-meta-data.xml file and will be triggered automatically in the package
	 * upgrading process.
	 * 
	 * User can also manaually run the script on command Line.
	 * 
	 * 
	 * The resource-manager 4.0.0 operational data model is not compapatible with
	 * previous version, in version 4.0.0 yang model, there is a new element
	 * "allocationId" for /id-allocator/pool/allocation needed to support sync
	 * allocation.
	 * 
	 * upgrade steps: 1) iterate all the resource-pools/id-pool 2) for each id-pool
	 * , log all the allocatons under the pool , and iterate all allocations for
	 * this pool 3) for each resource-pools/id-pool/allocation, check if it is
	 * successfully allocated (alloc.response.id not empty), if true, then set the
	 * new element allocationId to the responseId (alloc.response.id) (
	 * idpool_id_allocator.allocation[responseId].allocationId = alloc.id )
	 * 
	 * Important: After run the script from commandLine, we must request package
	 * reload or restart ncs to reload new CBD data into ID Pool java object in
	 * memory. For example, in nso-cli console, admin@ncs> request packages reload
	 * force
	 * 
	 * """
	 */
	public static void checkAllAllocations(Maapi maapi,int tid ,String poolName,String operation) throws ConfException, IOException, AllocationException {
			
			LOGGER.info("checkAllAllocations  for pool "+poolName +"   operation = "+ operation);

		  	NavuContext context = new NavuContext(maapi, tid);
	        NavuContainer base  = new NavuContainer(context);
	        NavuContainer root  = base.container(resourceAllocator.hash);
	        
	        NavuList idpool = root.container(resourceAllocator._resource_pools_).list(new idAllocator(),idAllocator._id_pool_);

	        /* Create id pools. */
	        for(NavuContainer pool : idpool.elements()) {
	        	String pname = pool.leaf("name").value().toString();
	        	LOGGER.info("checking resource pool =  "+pname);
	        	if(poolName !=null && !poolName.equals(pname)) {
	        		continue;
	        	}
	        	
	        	Pool p = IdAllocator.getPool(pname);

	        	for(Allocation a : p.idPool.getAllocations()) {
	        		LOGGER.info("	id_allocator:   allocated = "+ a.getAllocated() +"   allocationId = " + a.getAllocationId());
	        	}
	        	
	        	for (NavuContainer allo:  pool.list(idAllocator._allocation_).elements()) {
	        		String alloId = allo.leaf(idAllocator._id).value().toString();
	        		LOGGER.info("	alloc "+alloId);
	        		if(allo.container(idAllocator._response).leaf(idAllocator._id).exists()) {
	        			ConfValue responseIdConfValue = allo.container(idAllocator._response).leaf(idAllocator._id).value();
	        			long responseId = ((ConfUInt32)responseIdConfValue).longValue();
	        			LOGGER.info("response/id "+responseId);
	        			Allocation aa = p.idPool.findAllocationByAllocatedId(responseId);
	        			LOGGER.info("find idPool Allocation " + aa);
	        			if(aa !=null) {
	        				if(aa.getAllocationId() ==null || aa.getAllocationId().isEmpty()){
	        					LOGGER.info(" missing Allocation Id");
	        					if(operation.equals("fix_missing_allocation_id")) {
	        						p.idPool.addAllocationId(aa, alloId);
	        						LOGGER.info(" update oper id-allocator = "+  responseId+ "  set allocationId = " +alloId);
	        					}
	        				}
	        				if(aa.getOccupants() ==null || aa.getOccupants().size()==0) {
	        					LOGGER.info(" missing Owner");
	        					if(operation.equals("fix_missing_owner")) {      
	        						addOwnerIdAllocator(p.idPool,allo,responseId);
	        						}
	        				}        				
	        				
	        			}else {
	        				LOGGER.info(" [warning]No Id found in oper id-allocator: "+ responseId);
	        				if(operation.equals("fix_missing_allocation")) {
	        					
	        					createIdAllocatorAlloc(p.idPool,allo,
	        							responseId,alloId);
	        				}
	        			}
	        			
	        		}else {
	        			LOGGER.warn("[warning]no response/id found for allocation " + alloId);
	        		}	
	        		
	        	}
	        		        	
	        }
	        
	        persistAll(null); 
		  
	}
	
	
	public static void addOwnerIdAllocator(IDPool idPool, NavuContainer allo,long allocatedId
			) throws NavuException, AllocationException {
		LOGGER.info("addOwnerAllocator: " +"  Allocation = "+ allocatedId);

		Set<String> owners = new HashSet<String>();
		for (ConfValue service : allo.leafList(idAllocator._allocating_service)) {
			LOGGER.info("add owner = "+service);
			ConfObjectRef objRef = (ConfObjectRef) service;
            owners.add(new ConfPath(objRef.getElems()).toString());
		 }

		idPool.setAllocationOccupants(allocatedId, owners);

	}
	
	//only allocate id from pool and update idpool state , without updating resource-pool/idpool/allocation/response/id

	public static void createIdAllocatorAlloc(IDPool idPool,NavuContainer allo,
			long requestedId,String allocationId) throws NavuException, AllocationException {
		LOGGER.info("createIdAllocatorAlloc "+ idPool.getName() +"  requestedId = "+requestedId);

		Set<String> owners = new HashSet<String>();
		for (ConfValue service : allo.leafList(idAllocator._allocating_service)) {
			LOGGER.info("add service = "+service);
			ConfObjectRef objRef = (ConfObjectRef) service;
            owners.add(new ConfPath(objRef.getElems()).toString());
		 }
		
		Allocation a = idPool.allocate(owners, requestedId,allocationId);
		LOGGER.info("Allocation return: "+a);

	}
	
	public static void checkSyncAllocations(String poolName) throws ConfException, IOException {
		
		com.tailf.pkg.idallocator.IdAllocator.Pool p = IdAllocator.getPool(poolName);
		if(p!=null) {
			IdAllocator.checkSyncAllocations(p.idPool);
			p.idPool.persistAll();
		}
					
	}
	
	public static void checkIpSyncAllocations(String poolName) throws ConfException, IOException, ResourceErrorException {
		
		com.tailf.pkg.ipaddressallocator.IPAddressAllocator.Pool p = IPAddressAllocator.getPool(poolName);
		IPAddressAllocator.checkSyncAllocations(p.ipPool);
				
					
	}
	/**
	 * 
	 * if poolName is null, then persisAll for all idPool
	 * if poolName is not null, then persisAll for the specific idPool
	 * @param poolName
	 * @throws ConfException
	 * @throws IOException
	 */
	public static void persistAll(String poolName) throws ConfException, IOException {
		if(poolName!=null) {
			Pool p = IdAllocator.getPool(poolName);
			if(p!=null) {
				p.idPool.persistAll();
			}
		}else {
			LOGGER.info("persistAll for all idPool");
			for(Pool pp:IdAllocator.pools) {
				pp.idPool.persistAll();
			}
		}
					
	}

	public static void main(String[] args) {	

	}

}
