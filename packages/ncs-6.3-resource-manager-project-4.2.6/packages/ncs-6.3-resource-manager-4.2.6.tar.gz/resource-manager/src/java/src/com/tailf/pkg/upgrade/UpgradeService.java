package com.tailf.pkg.upgrade;

import java.util.Objects;
import java.net.Socket;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

import com.tailf.cdb.Cdb;
import com.tailf.cdb.CdbDBType;
import com.tailf.cdb.CdbLockType;
import com.tailf.cdb.CdbSession;
import com.tailf.cdb.CdbException;
import com.tailf.conf.Conf;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfIP;
import com.tailf.conf.ConfObjectRef;
import com.tailf.conf.ConfPath;
import com.tailf.conf.ConfUInt8;
import com.tailf.conf.ConfUInt32;
import com.tailf.maapi.Maapi;

public class UpgradeService {

    static class Pair<K, V> {
        private final K first;
        private final V second;

        public Pair(K first, V second) {
            this.first = first;
            this.second = second;
        }

        public K getFirst() {
            return first;
        }

        public V getSecond() {
            return second;
        }

        @Override
        @SuppressWarnings("unchecked")
        public boolean equals(Object other) {
            if ( this == other) return true;
            if ( other == null || other.getClass() != this.getClass() ) return false;

            Pair<K,V>  otherPair = (Pair<K,V>) other;
            return Objects.equals(this.first, otherPair.first) 
                    && Objects.equals(this.second, otherPair.second);
        }

        @Override
        public int hashCode() {
            return Objects.hash(first, second);
        }
        
    }

    public UpgradeService() {
    }

    public static void main(String[] args) throws Exception {
        System.out.println("::::UpgradeResourceManager Start::::");
        HashMap<Pair<ConfBuf, ConfBuf>, ConfPath> idpoolAllocToService = 
            new HashMap<Pair<ConfBuf, ConfBuf>, ConfPath>();
        int port = Integer.parseInt(System.getenv("NCS_IPC_PORT"));
        Socket s1 = new Socket("localhost", port);
        Cdb cdb = new Cdb("cdb-upgrade-sock", s1);
        cdb.setUseForCdbUpgrade();
        CdbSession cdbRunning =
            cdb.startSession(
                    CdbDBType.CDB_RUNNING,
                    EnumSet.of(CdbLockType.LOCK_SESSION,
                               CdbLockType.LOCK_WAIT));
        Socket s2 = new Socket("localhost", port);
        Maapi maapi = new Maapi(s2);
        int th = maapi.attachInit();

        try {
            cdbRunning.exists("/resource-pools");
        } catch (CdbException ce) {
            System.out.println("::::UpgradeResourceManager No Upgrade Needed::::");
            if(ce.getMessage() != null && ce.getMessage().contains("Bad path element")) {
                s1.close();
                s2.close();
                return;
            }
        }

        // Map id-pool pool allocations to allocating-service
        int noIdPools = cdbRunning.getNumberOfInstances("/ralloc:resource-pools/idalloc:id-pool");  
        for (int poolIdx = 0; poolIdx < noIdPools; poolIdx++) {
            ConfBuf poolName = (ConfBuf) cdbRunning.getElem("/ralloc:resource-pools"
                                                             + "/idalloc:id-pool[%d]/name",
                                                             poolIdx);
            int noAllocations = cdbRunning.getNumberOfInstances("/ralloc:resource-pools"
                                                             + "/idalloc:id-pool[%d]"
                                                             + "/allocation",
                                                             poolIdx);

            for (int allocIdx = 0; allocIdx < noAllocations; allocIdx++) {
                ConfBuf allocationName = (ConfBuf) cdbRunning.getElem("/ralloc:resource-pools"
                                                         + "/idalloc:id-pool[%d]"
                                                         + "/allocation[%d]/id",
                                                         poolIdx,
                                                         allocIdx);
                if (cdbRunning.exists("/ralloc:resource-pools/idalloc:id-pool[%d]/allocation[%d]" 
                            + "/allocating-service", poolIdx, allocIdx)) {
                    ConfObjectRef allocatingService = (ConfObjectRef) cdbRunning.getElem("/ralloc:resource-pools"
                                                         + "/idalloc:id-pool[%d]"
                                                         + "/allocation[%d]"
                                                         + "/allocating-service",
                                                         poolIdx,
                                                         allocIdx);

                    if (!allocatingService.toString().isEmpty()) {
                        Pair<ConfBuf, ConfBuf> key = new Pair<ConfBuf, ConfBuf>(poolName, allocationName);
                        idpoolAllocToService.put(key, new ConfPath(allocatingService.getElems()));
                    }
                }
            }
        }
        cdbRunning.endSession();
        System.out.println("MAP: " + idpoolAllocToService);

        // Populate new id-allocator owners leaf-list oper data
        CdbSession cdbOper =
            cdb.startSession(CdbDBType.CDB_OPERATIONAL);
        for (Map.Entry<Pair<ConfBuf, ConfBuf>, ConfPath> entry : idpoolAllocToService.entrySet()) {
            Pair<ConfBuf, ConfBuf> pair = entry.getKey();
            ConfPath service = entry.getValue();
            ConfBuf poolName = pair.getFirst();
            ConfBuf allocationName = pair.getSecond();

            if (cdbOper.exists("/resource-pools/idalloc:id-pool{%x}/allocation{%x}" 
                        + "/response/id", poolName, allocationName)) {
                ConfUInt32 allocatedId = (ConfUInt32) cdbOper.getElem("/resource-pools"
                                                         + "/idalloc:id-pool{%x}"
                                                         + "/allocation{%x}"
                                                         + "/response/id",
                                                         poolName,
                                                         allocationName);
                if (cdbOper.exists("/id-allocator/pool{%x}/allocation{%x}",
                            poolName, allocatedId)) {
                    maapi.safeCreate(th, "/id-allocator/pool{%x}/allocation{%x}/owners{%x}",
                                 poolName, allocatedId, service); 
                }
            }

        }
       
        // Populate new ip-allocator owners leaf-list oper data
        int noIpAddressPools = cdbOper.getNumberOfInstances("/ipalloc-oper:ip-allocator/pool");  
        for (int poolIdx = 0; poolIdx < noIpAddressPools; poolIdx++) {
             ConfBuf poolName = (ConfBuf) cdbOper.getElem("/ipalloc-oper:ip-allocator"
                                                        + "/pool[%d]/name",
                                                        poolIdx);
             int noAllocations = cdbOper.getNumberOfInstances("/ipalloc-oper:ip-allocator"
                                                        + "/pool[%d]/allocation",
                                                        poolIdx);

            for (int allocIdx = 0; allocIdx < noAllocations; allocIdx++) {
                ConfIP allocAddress = (ConfIP) cdbOper.getElem("/ipalloc-oper:ip-allocator"
                                                         + "/pool[%d]/allocation[%d]"
                                                         + "/address",
                                                         poolIdx,
                                                         allocIdx);
                ConfUInt8 allocMask = (ConfUInt8) cdbOper.getElem("/ipalloc-oper:ip-allocator"
                                                         + "/pool[%d]/allocation[%d]"
                                                         + "/cidrmask",
                                                         poolIdx,
                                                         allocIdx);
                if (cdbOper.exists("/ipalloc-oper:ip-allocator/pool[%d]/allocation[%d]"
                            + "/owner", poolIdx, allocIdx)) {
                    ConfBuf owner = (ConfBuf) cdbOper.getElem("/ipalloc-oper:ip-allocator"
                                                              + "/pool[%d]/allocation[%d]"
                                                              + "/owner",
                                                              poolIdx,
                                                              allocIdx);
                    if (!owner.toString().isEmpty()) {
                        maapi.safeCreate(th,
                                     "/ipalloc-oper:ip-allocator/pool{%x}"
                                     + "/allocation{%x %x}/owners{%x}",
                                     poolName, allocAddress, allocMask, owner); 
                    }
                }
            }
        }

        s1.close();
        s2.close();
        System.out.println("::::UpgradeResourceManager Done::::");
    }
}

