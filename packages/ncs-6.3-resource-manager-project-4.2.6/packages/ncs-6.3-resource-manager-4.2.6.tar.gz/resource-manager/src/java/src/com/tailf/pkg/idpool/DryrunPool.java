package com.tailf.pkg.idpool;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;


import com.tailf.pkg.idpool.exceptions.AllocationException;


public class DryrunPool extends IDPool {

    private static Logger LOGGER = Logger.getLogger(DryrunPool.class);

   public DryrunPool() {
	   
	    this.availables  = new TreeSet<Range>();
        this.allocations = new HashSet<Allocation>();
		  
   }

   public synchronized void populate(IDPool idPool) {
	   this.availables.clear();
	   this.allocations.clear();
	   idPool.availables.forEach(range -> this.availables.add(new Range(range)));
	   idPool.allocations.forEach(alloc -> this.allocations.add(new Allocation(alloc)));
	   this.lastAllocation =  idPool.lastAllocation;
	   this.max =  idPool.max;
	   this.min =  idPool.min;
	   this.name = idPool.name + "_Dryrun";
	   
	   
   }
   public synchronized Allocation allocateDryrun(Set<String> occupants, String requestMethod, long requestedId,String allocationId)
  		 throws AllocationException{
	   
	   return requestedId == -1 ? allocate(occupants, requestMethod,allocationId) : allocate(occupants, requestedId,allocationId);           
   }
   
   
  
}
