#!/usr/bin/env python3
"""
gen_ssl_certs.py - utility to generate SSL certificates for HA RAFT test cases
"""

from argparse import ArgumentParser
import os
import re
from pathlib import Path
import subprocess
import json


def usage():
    print("""gen_ssl_certs.py - utility to generate SSL certificates for HA RAFT test cases

Usage: python gen_ssl_certs.py [-h|--help] hostsfile
positional arguments:
  hostsfile             hostsfile.json file path

optional arguments:
  -h, --help            show this help message and exit
    """)


def subprocess_cmd(cmd):
    try:
        result = subprocess.run(cmd, encoding='UTF-8', stdout=subprocess.PIPE)
        return result.stdout
    except subprocess.CalledProcessError:
        raise


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('hostsfile', help='hostsfile file path')
    args = parser.parse_args()
    hostsfile = str(Path(args.hostsfile).absolute())

    if not os.path.exists(hostsfile):
        print(f"ERROR: The hosts file {hostsfile} does not exist")
        exit(1)
    if os.environ.get('NCS_DIR') is None:
        print(f"ERROR: The NCS_DIR environment variable is not defined")
        exit(1)

    with open(hostsfile, 'r') as hf:
        host_info = json.loads(hf.read())

    hosts = dict()
    for host in host_info['hosts']:
        name = host.get('name')
        ip = host.get('address')
        if name and ip:
            hosts[name] = ip

    raft_dir = str(Path(__file__).parent.parent)
    tpl_dir = os.path.join(raft_dir, "tpl")
    certext = os.path.join(tpl_dir, "certext.in")
    with open(certext, 'r') as fr:
        ip_template = fr.read()

    for hostname in hosts:
        with open(f"./{hostname}.cnf", "w") as cf:
            cf.write(ip_template.replace("127.0.0.1", hosts[hostname]))

    cmd_args = [f"{raft_dir}/helpers/gen_tls_certs.sh", "-d", f"{raft_dir}"]
    cmd_args.extend(list(hosts.keys()))
    res = subprocess_cmd(cmd_args)
    for hostname in hosts:
        os.remove(f"{hostname}.cnf")
