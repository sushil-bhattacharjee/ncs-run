
import ncs
## remove allocationId element of /id_allocation.pool[pool_test]/allocation
## for testing "rm-upgrade" script
pool_test = "management"
def rm_upgrade_test():
    print("pool = "+pool_test)
    with ncs.maapi.Maapi() as m:
        with ncs.maapi.Session(m, 'admin', 'system'):
            with m.start_write_trans() as t:
                root = ncs.maagic.get_root(t)
                if pool_test in root.id_allocator.pool:
                    idpool_id_allocator = root.id_allocator.pool[pool_test]
                
                    for oper_allocation in idpool_id_allocator.allocation:
                        print('  before remove: oper allocation = {}, allocationId = {}'.format(oper_allocation.id,oper_allocation.allocationId))
                        del oper_allocation.allocationId
 #                       oper_allocation.allocationId= None;
                        print('        after remove: allocationId = {}'.format(oper_allocation.allocationId))
                    t.apply()
                else:
                     print("the pool not exist")


if __name__ == '__main__':
    rm_upgrade_test()
