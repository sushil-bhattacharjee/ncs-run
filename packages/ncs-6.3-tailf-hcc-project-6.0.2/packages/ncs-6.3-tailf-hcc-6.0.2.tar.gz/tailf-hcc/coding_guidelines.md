# Coding guidelines

To increase the likelihood that your contributions will be accepted
try to follow these guidelines when you are contributing.

The guidelines aims to make all code look and "feel" the same. This
simplifies understanding code and speeds up code reading.

We have a set of general guidelines and guidelines specific to what
programming language you are developing in. Please read through the
general guidelines first and then take a look at the specific
programming language guidelines.

## General guidelines

* Keep the lines 80 characters long
* Follow the "style" of existing code when extending
* Do not commit commented-out code
* Make sure your comments are correct and helpful

* Use the ```ncs-make-package``` and ```ncs-project``` tools when
  applicable. These tools creates the framework you need to easily use
  your code with NSO.

For more information about how to develop NSO applications read the
NSO development guide (the file is named nso_development-<nso-version>.pdf).

## Erlang coding guidelines

In general
* Use types
* Do not "export all"

Take a look at [Inaka's guidelines](https://github.com/inaka/erlang_guidelines).
