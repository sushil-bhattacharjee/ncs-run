package com.tailf.pkg.idallocator;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;
import org.apache.log4j.Logger;

import com.tailf.pkg.idallocator.namespaces.idAllocator;
import com.tailf.pkg.idallocator.namespaces.idAllocatorOper;
import com.tailf.pkg.idpool.Allocation;
import com.tailf.pkg.resourcemanager.ResourceErrorException;
import com.tailf.pkg.resourcemanager.namespaces.resourceAllocator;
import com.tailf.cdb.CdbSession;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfList;
import com.tailf.conf.ConfNoExists;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfPath;
import com.tailf.conf.ConfUInt32;


/**
 * AllocationsSet
 *
 */
public class AllocationsSet extends HashSet<Allocation> {

    private static final long serialVersionUID = -7899235036264236762L;
    private static Logger LOGGER = Logger.getLogger(AllocationsSet.class);

    private ConfPath allocPath;
    private CdbSession wsess;

    public AllocationsSet() {
    	 super();
    	
    }
    public AllocationsSet(CdbSession wsess, String poolName) {
        super();

        this.wsess = wsess;

        LOGGER.debug("Creating AllocationsSet");

        /* Populate from allocations stored in CDB. */
        try {
            allocPath = new ConfPath("/%s:%s/%s{\"%s\"}",
                    idAllocatorOper.prefix, idAllocatorOper._id_allocator_,
                    idAllocatorOper._pool_, poolName);

            /* We have configured a pool but it isn't set up in oper data yet. */
            if (wsess.exists(allocPath) == false) {
                LOGGER.debug(String.format(
                            "Operational pool %s missing, creating.",
                            poolName));
                wsess.create(allocPath);
            }

            allocPath.append(idAllocatorOper._allocation_);

            

            int n = wsess.getNumberOfInstances(allocPath);
            LOGGER.debug("Adding existing " + n +  " allocations" );
            if (n > 0) {
                List<ConfObject[]> objs = wsess.getObjects(3, 0, n, allocPath);

                for (ConfObject[] obj : objs) {
                    long id = ((ConfUInt32) obj[0]).longValue();
                    String requestId = obj[2] instanceof ConfNoExists ? "" :((ConfBuf)obj[2]).toString();
                    HashSet<String> owners = new HashSet<String>();

                    if (obj[1] instanceof ConfList) {
                        ConfList ownersConfList = (ConfList) obj[1];
                        for (ConfObject ownerObj : ownersConfList.elements()) {
                            String owner = ((ConfBuf) ownerObj).toString();
                            owners.add(owner);
                        }
                    }

                    LOGGER.debug(String.format("Adding Allocation(%d)", id));
                    super.add(new Allocation(id, owners,requestId));
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to setup up AllocationsSet", e);
        }
    }

    public boolean add(Allocation e) {
        boolean res = super.add(e);
        return res;
        
    }
    
    
    public void addToCdb(Allocation e) {
    	
    	 try {
             long id = e.getAllocated();
             LOGGER.debug("addToCdb "+e);
             String p = String.format("%s{%s}",
                             this.allocPath.toString(),
                             Long.toString(id));
             this.wsess.create(p);
             this.wsess.setElem(new ConfBuf(e.getAllocationId()),
                     new ConfPath(p + "/" +
                                  idAllocatorOper._allocationId_));
             
             

             for (String occupant : e.getOccupants()) {
                 ConfPath ownerElem = new ConfPath("%s{\"%s\"}/%s{%x}",
                         this.allocPath.toString(),
                         e.getAllocated(),
                         idAllocatorOper._owners_,
                         new ConfBuf(occupant));
                 this.wsess.create(ownerElem);
             }
         } catch (Exception ex) {
             LOGGER.error("Could not add allocation", ex);
         }
    	
    	
    }

    public boolean remove(Object o) {
        boolean res = super.remove(o);
        return res;
    }

   
    public void removeFromCdb(Object o) {
    	 try {
    		 Allocation e = (Allocation) o;
             long id = e.getAllocated();
             LOGGER.debug("removeFromCdb "+e);
             String p = String.format("%s{%s}",
                             this.allocPath.toString(),
                             Long.toString(id));
             this.wsess.delete(p);
         } catch (Exception ex ) {
             LOGGER.error("Could not remove allocation", ex);
         }
    	
    }
    
    public void clear() {
        super.clear();
    }
    
    public void clearFromCdb() {
    	 try {
    		 int n = wsess.getNumberOfInstances(allocPath);
             if (n>0) {
                 this.wsess.delete(this.allocPath);
             }
             LOGGER.debug("after clearFromCdb, numberOfInstance = "+ wsess.getNumberOfInstances(allocPath));
         } catch (Exception ex ) {
             LOGGER.error("Failed to clear allocations", ex);
         }  
    	 
    	
    }
    
    public long getAllocatedId(String poolName, String allocationId)
            throws ConfException, IOException, ResourceErrorException
        {
            long allocatedId = -1;
            
               
                ConfPath poolPath = new ConfPath("/%s:%s/%s:%s{\"%s\"}",
                                                 resourceAllocator.prefix, resourceAllocator._resource_pools_,
                                                 idAllocator.prefix, idAllocator._id_pool_, poolName);

               

                ConfPath allocPath = poolPath.copyAppend("/allocation{" + allocationId + "}");

                if (wsess.exists(allocPath) == false) {
                    return -1;
                }

                ConfPath idPath = allocPath.copyAppend("/response/id");

                if (wsess.exists(idPath)) {
                    allocatedId = ((ConfUInt32)wsess.getElem(idPath)).longValue();
                    LOGGER.debug(" [AllocationsSet] getAllocatedId  = "+ allocatedId);
                }
                

                return allocatedId;

        }
    
    
public HashSet<Allocation> loadCdb() {
                
        HashSet<Allocation> result = new HashSet<Allocation>();
        try {
            
        	 int n = wsess.getNumberOfInstances(allocPath);
             if (n > 0) {
                 List<ConfObject[]> objs = wsess.getObjects(3, 0, n, allocPath);

                 for (ConfObject[] obj : objs) {
                     long id = ((ConfUInt32) obj[0]).longValue();
                     String requestId = obj[2] instanceof ConfNoExists ? "" :((ConfBuf)obj[2]).toString();
                     HashSet<String> owners = new HashSet<String>();

                     if (obj[1] instanceof ConfList) {
                         ConfList ownersConfList = (ConfList) obj[1];
                         for (ConfObject ownerObj : ownersConfList.elements()) {
                             String owner = ((ConfBuf) ownerObj).toString();
                             owners.add(owner);
                         }
                     }
                     result.add(new Allocation(id, owners,requestId));
                 }
             }
        } catch (Exception e) {
            LOGGER.error("Failed to loadCdb AllocationSet", e);
        }
        return result;
    }

    public void syncToCdb() {
    	
    	HashSet<Allocation> cdbAllocations = this.loadCdb();
    	
    	for (Allocation cdb_alloc: cdbAllocations) {   		
    		if(!this.contains(cdb_alloc)) {
    			this.removeFromCdb(cdb_alloc);
    		}
    	}
    	for(Allocation allocation : this) {
    		if (!cdbAllocations.contains(allocation)){
    			this.addToCdb(allocation);    			
    		}    		
    	}    	
    }
       

}
