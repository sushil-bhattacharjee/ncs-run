#!/bin/bash

source /opt/ncs/current/ncsrc

NCS_VERSION=$(ncs --version)
NCS_MAJOR=$(ncs --version | awk -F "." '{print $1}')
NCS_MINOR=$(ncs --version | awk -F "." '{print $2}')
NCS_VER_SHORT=$NCS_MAJOR.$NCS_MINOR

echo "NCS_VER_SHORT: $NCS_VER_SHORT"
JDK17_SUPPORTED=$(echo $NCS_VER_SHORT 6.2 | awk '{ print ($$1 >= $$2) ? "true" : "false" }')
echo "JDK17_SUPPORTED: $JDK17_SUPPORTED"
if [ "$JDK17_SUPPORTED" = "true" ];then
  echo "setting java 17"
  echo "root" | sudo update-alternatives --set java /usr/lib/jvm/jdk-17.0.2/bin/java
  export JAVA_HOME="/usr/lib/jvm/jdk-17.0.2"
fi
echo "JAVA_HOME: $JAVA_HOME"