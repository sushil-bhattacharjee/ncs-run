#!/bin/sh
#
# Bash script to check, if the NSO version supports HA RAFT.
# The script returns 'true', if NSO version is equal or greater 6.1.2;
# otherwise - 'false'.
#
# Usage: ./raft_supported.sh nso_version
# ------------------------------------------------------------------------------

if [ -z "$1" ]
then
  echo "Missing required script parameter - nso_version"
  echo "Usage: ./raft_supported.sh nso_version"
  exit 1
fi

lower=$(printf "%s\n6.1.2\n" "$1" | sort -V | head -n 1)
if [  "$lower" = "6.1.2" ]; then
  echo true
else
  echo false
fi
