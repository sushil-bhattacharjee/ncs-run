package com.tailf.pkg.idpool;

import java.io.Serializable;
import java.util.Objects;
import java.util.Set;


public class Allocation implements Serializable {

    private static final long serialVersionUID = 2068013029116522734L;
    private long allocated;
    private Set<String> occupants;
    private String allocationId;

  
	public Allocation() {}

	public Allocation(long allocated, Set<String> occupants,String allocationId) {
	        this.allocated = allocated;
	        this.occupants = occupants;
	        this.allocationId = allocationId;
	  
	    }
    public Allocation(long allocated, Set<String> occupants) {
        this.allocated = allocated;
        this.occupants = occupants;
  
    }

    public Allocation(Allocation that) {
        super();
        this.allocated = that.allocated;
        this.occupants = that.occupants;
        this.allocationId = that.allocationId;
    }

    public long getAllocated() {
        return allocated;
    }

    public void setAllocated(long segment) {
        this.allocated = segment;
    }

    public Set<String> getOccupants() {
        return this.occupants;
    }

    public void setOccupants(Set<String> occupants) {
        this.occupants = occupants;
    }
    public void addOccupant(String occupant) {
    	
    	this.occupants.add(occupant);
    }
    
    public String getAllocationId() {
  		return allocationId;
  	}

  	public void setAllocationId(String allocationId) {
  		this.allocationId = allocationId;
  	}
  	
  	public boolean containsOtherOwner(String occupant) {
  		for(String owner: this.occupants) {
  			if (!owner.equals(occupant)) return true;
  		}
  		return false;
  	}

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return String.format("{\"segment\": %s, \"occupants\": %s, \"allocationId \" : %s}",
                             allocated, occupants,this.allocationId);
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     * This function order the iterator returns ranges.
     */
    @Override
    public int hashCode() {

    	return Objects.hash(this.allocated,this.allocationId,this.occupants);
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }
        Allocation other = (Allocation) obj;  
        
        return     Objects.equals(allocated, other.allocated)
				&& Objects.equals(allocationId, other.allocationId)
        		&& Objects.equals(occupants, other.occupants); 

    }
}
