%% HCC VIP layer-2 high availability server.
-module(tailf_hcc_server).

-behaviour(gen_server).

%% API
-export([start_link/0]).

%% gen_server callbacks
-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
         terminate/2, code_change/3]).

%% internal exports
-export([notif_init/0, cdb_init/0]).

-include("econfd.hrl").
-include("econfd_errors.hrl").

-define(SERVER, ?MODULE).

-define(ns, 'http://cisco.com/pkg/tailf-hcc').
-define(ncs_ns, 'http://tail-f.com/ns/ncs').
-define(haraft_ns, 'http://tail-f.com/ns/ncs/high-availability/raft').
-define(hcc_ikp, [[?ns|'hcc']]).
-define(ncs_ha_ikp, [[?ncs_ns|'high-availability']]).
-define(dns_ikp, [dns|?hcc_ikp]).

-record(neighbor,
        { enabled      :: boolean(),
          address      :: string(),
          as           :: integer(),
          min_ttl      :: undefined | integer(),
          multihop_ttl :: undefined | integer(),
          password     :: undefined | string(),
          state=""     :: string()
        }).

-record(bgp,
        {enabled       :: boolean(),
         as            :: integer(),
         router_id     :: string(), %% IPv[46] address
         neighbors     :: [#neighbor{}],
         %% Running state
         on_exit_port  :: undefined|port(), %% to shutdown gobgpd on erlang exit
         port          :: undefined|port(), %% Erlang pid of GoBGP
         ospid         :: undefined|integer(), %% OS pid of GoBGP
         advertised=[] :: [string()], %% ip addresses currently advertised
         node_id       :: undefined | binary(),
         conf_path     :: undefined | list() %% path to bgp config file
        }).

-record(dns,
        {enabled    :: boolean(),
         node_ip    :: string(), %% IPv4/IPv6 address
         fqdn       :: binary(), %% Fully Qualified domain name
         ttl        :: integer(), %% time to live
         key_file   :: undefined|binary(), %% Key file location
         server     :: undefined|string(), %% DNS server address IPv4/IPv6
         port       :: undefined|integer(), %% DNS Server port
         zone       :: undefined|binary(),
         timeout    :: integer() %% timeout for nsupdate
        }).

-record(state,
        {role=disabled  :: primary | secondary | disabled,
         vips=[]        :: [string()], %% VIP address list (IPv4/IPv6)
         vipctl=""      :: string(), %% path to vipctl helper script
         on_exit_vipctl :: undefined | port(), %% to run vipctl down
         bgp=disabled   :: disabled | #bgp{}
        }).

%%%===================================================================
%%% API
%%%===================================================================

start_link() ->
    gen_server:start_link({local, ?SERVER}, ?MODULE, [], []).

cast(Msg) ->
    gen_server:cast(?SERVER, Msg).

%%%===================================================================
%%% gen_server callbacks
%%%===================================================================

%%--------------------------------------------------------------------
init([]) ->
    process_flag(trap_exit, true), % Triggers call to terminate/2
    econfd:log(?CONFD_LEVEL_TRACE, "~p: Server starting...", [?SERVER]),
    proc_lib:start_link(?MODULE, notif_init, []),
    proc_lib:start_link(?MODULE, cdb_init, []),
    init_confd_callbacks(),
    State = update(#state{}, _Force = true, none),
    {ok, State}.

%% Helper process to convert synchronous cluster status events into
%% asynchronous casts.
notif_init() ->
    register(tailf_viperl_server_notif, self()),
    {ok, Sock} = econfd_notif:connect({127,0,0,1}, ?NCS_PORT,
                                      ?CONFD_NOTIF_HA_INFO bor
                                          ?CONFD_NOTIF_UPGRADE_EVENT),
    proc_lib:init_ack(ok),
    notif_loop(Sock).

notif_loop(Sock) ->
    case econfd_notif:recv(Sock) of
        {ok, Notif} ->
            cast({event, Notif}),
            notif_loop(Sock);
        {error, timeout} ->
            notif_loop(Sock);
        {error, Error} ->
            econfd:log( ?CONFD_LEVEL_ERROR,
                        "~p: Error receving event notification: ~p",
                        [?SERVER, Error]
                      ),
            notif_init()
    end.

%% Helper process to convert synchronous cdb update events into
%% asynchronous casts.
cdb_init() ->
    register(tailf_viperl_server_cdb, self()),
    {ok, S} = econfd_cdb:connect({127,0,0,1}, ?NCS_PORT),
    econfd_cdb:wait_start(S),
    {ok, Sub} = econfd_cdb:subscribe_session(S),
    {ok, _Point1} = econfd_cdb:subscribe(Sub, 100, ?ns, "/hcc"),
    ok = econfd_cdb:subscribe_done(Sub),
    proc_lib:init_ack(ok),
    cdb_loop(Sub).

cdb_loop(Sub) ->
    F = fun(_) -> cast({event, cdb_update}), ?CDB_DONE_SOCKET end,
    ok = econfd_cdb:wait(Sub, infinity, F),
    cdb_loop(Sub).

init_confd_callbacks() ->
    {ok, Daemon} = econfd:init_daemon(?SERVER, ?CONFD_TRACE, user, none,
                                      {127,0,0,1}, ?CONFD_PORT),
    TransCbs = #confd_trans_cbs{init = fun init_trans/1},
    ok = econfd:register_trans_cb(Daemon, TransCbs),
    ActFn = fun(_, [_|Cmd], _, _) -> gen_server:cast(?SERVER, Cmd) end,
    ActCB = #confd_action_cb {
               actionpoint = 'hcc-action',
               action = ActFn
              },
    ok = econfd:register_action_cb(Daemon, ActCB),
    ok = econfd:register_action_cb(Daemon, #confd_action_cb {
                                        actionpoint = 'hcc-dns-update-action',
                                        action = fun action_cb/4
                                    }),
    ok = econfd:register_action_cb(Daemon, #confd_action_cb {
                                        actionpoint = 'hcc-get-node-location-action',
                                        action = fun action_cb/4
                                    }),
    CompletionActCB =  #confd_action_cb {
               actionpoint = 'hcc-complete-members',
               completion = fun completion_cb/9
              },
    ValidationCB = #confd_valpoint_cb {
                valpoint = 'hcc-validate-members',
                validate = fun validation_cb/3
              },
    ok = econfd:register_action_cb(Daemon, CompletionActCB),
    ok = econfd:register_valpoint_cb(Daemon, ValidationCB),
    ok = econfd:register_valpoint_cb(Daemon, #confd_valpoint_cb {
                                        valpoint = 'hcc-validate-dns-member',
                                        validate = fun validation_cb/3
                                    }),
    ok = econfd:register_valpoint_cb(Daemon, #confd_valpoint_cb {
                                        valpoint = 'hcc-validate-gobgp',
                                        validate = fun validation_cb/3
                                    }),
    Data = #confd_data_cbs {
              callpoint = 'hcc-data',
              get_elem = fun get_elem/2,
              get_next = fun get_next/3
             },
    ok = econfd:register_data_cb(Daemon, Data),
    ok = econfd:register_done(Daemon),
    econfd:log(?CONFD_LEVEL_INFO, "~p: Registered econfd callbacks",
               [?SERVER]),
    ok.
%%
handle_call({bgpd_pid, NodeId}, _From, #state{bgp=BGP} = State) ->
    Reply = case BGP of
                #bgp{node_id=NodeId, ospid=OSPid} when is_integer(OSPid) ->
                    {pid, OSPid};
                _ ->
                    undefined
            end,
    {reply, Reply, State};
handle_call({neighbor_state, NodeId, IP}, _From, #state{bgp=BGP} = State) ->
    Reply = case BGP of
                #bgp{node_id=NodeId, neighbors=Neighbors} ->
                    case lists:keysearch(IP, #neighbor.address, Neighbors) of
                        {value, N} ->
                            {state, list_to_binary(N#neighbor.state)};
                        false ->
                            undefined
                    end;
                _ ->
                    undefined
            end,
    {reply, Reply, State};
handle_call(Req, _From, State) ->
    econfd:log(
      ?CONFD_LEVEL_ERROR, "~p: Got unexpected call: ~p", [?SERVER, Req]),
    {reply, error, State}.


%%
handle_cast({event, What}, State) ->
    %% React to any external event by polling the current state of the world.
    Force  = case What of
                 cdb_update -> true;
                 force      -> true;
                 _          -> false
             end,
    {noreply, update(State, Force, What)};
handle_cast({force_status, Status}, State) ->
    put(force_status, Status),
    {noreply, update(State, _Force = true, none)};
handle_cast(Req, State) ->
    econfd:log(
      ?CONFD_LEVEL_ERROR, "~p: Got unexpected cast: ~p", [?SERVER, Req]),
    {noreply, State}.


handle_info({'EXIT', Port, Reason}, State = #state{bgp = BGP})
  when Port == BGP#bgp.port ->
    econfd:log(?CONFD_LEVEL_ERROR,
               "~p: BGP daemon with pid ~p terminated unexpectedly: ~p",
               [?SERVER, BGP#bgp.ospid, Reason]),
    cancel_on_exit(BGP#bgp.on_exit_port),
    file:delete(BGP#bgp.conf_path),
    State1 = State#state{bgp=BGP#bgp{ospid=undefined,
                                     port=undefined,
                                     conf_path=undefined}},
    {stop, {bgpd_error, Reason}, State1};
handle_info({_Port, {data, Data}}, State) ->
    {eol, Line} = Data,
    BGP1 = input_bgp_event(State#state.bgp, Line),
    {noreply, State#state{bgp = BGP1}};
handle_info(Info, State) ->
    econfd:log(?CONFD_LEVEL_ERROR, "~p: Got unexpected info: ~p~n",
               [?SERVER, Info]),
    {noreply, State}.

%%
terminate(Reason, State) ->
    maybe_stop_bgp(State#state.bgp),
    econfd:log(?CONFD_LEVEL_TRACE, "~p: Server stopped - ~p",
               [?SERVER, Reason]),
    ok.

%%
code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%--------------------------------------------------------------------
%% Completion action and Validation callbacks

completion_cb(#confd_user_info{usid = USid, actx = Actx},
              _CliStyle, _Token, _CompletionChar,
              _KP, _CmdPath, _Id, _TP, _Extra) ->
    {ok, M} = econfd_maapi:connect({127,0,0,1}, ?NCS_PORT),
    Th = Actx#confd_action_ctx.thandle,
    try
        ok = econfd_maapi:attach2(M, 0, USid, Th),
        member_list(M, Th)
    after
        econfd_maapi:detach(M, Th),
        econfd_maapi:close(M)
    end.

validation_cb(#confd_trans_ctx{thandle = Th} = Tctx,
              KP, NewVal) ->
    {ok, M} = econfd_maapi:connect({127,0,0,1}, ?NCS_PORT),
    try
        ok = econfd_maapi:attach(M, 0, Tctx),
        validate(M, Th, NewVal, KP)
    catch
        _:_ -> ok
    after
        econfd_maapi:detach(M, Th),
        econfd_maapi:close(M)
    end.

%% Validate: if gobgp and gobgpd is installed while setting /hcc/bgp (if enabled=true)
validate(M, Th, _, [NodeId,node,bgp|?hcc_ikp]) ->
    case bgp_enabled(M, Th, NodeId) of
        true ->
            try
                find_executable("gobgp"),
                find_executable("gobgpd"),
                ok
            catch
                error:_Err ->
                    {error, "gobgp/gobgpd not found"}
            end;
        disabled ->
            ok
    end;

%% Validate /hcc/bgp/node/node-id
validate(M, Th, NewVal, ['node-id',_,node,bgp|?hcc_ikp]) ->
    validate_member(M, Th, NewVal);
%% Validate /hcc/dns/member list
validate(M, Th, NewVal, ['node-id',_,member|?dns_ikp]) ->
    {ok, Members} = member_list(M, Th),
    case lists:member(binary_to_list(NewVal), Members) of
        true ->
            {ok, L} = econfd_maapi:all_keys(M, Th, [member|?dns_ikp]),
            DNS_Members = [binary_to_list(X) || {X} <- L],
            case Members -- DNS_Members of
                [] -> ok;
                _ -> {error, "Please define all HA members in /hcc/dns/member"}
            end;
        false ->
            {error, "Invalid node value"}
    end.

validate_member(M, Th, NewVal) ->
    {ok, Members} = member_list(M, Th),
    case lists:member(binary_to_list(NewVal), Members) of
        true ->
            ok;
        false ->
            {error, "Invalid node value"}
    end.

member_list(M, Th) ->
    %% /ha-raft/status/member only exists if an HA Raft cluster exists,
    %% /ha-raft/status/role exists if /ncs-config/ha-raft/enabled
    case econfd_maapi:exists(M, Th, [role,status,[?haraft_ns|'ha-raft']]) of
        {ok, true} ->
            list_keys(M, Th, [member,status,[?haraft_ns|'ha-raft']]);
        _ ->
            list_keys(M, Th, ['ha-node'|?ncs_ha_ikp])
    end.

list_keys(M, Th, IKP) ->
    case econfd_maapi:all_keys(M, Th, IKP) of
        {ok, L} ->
            {ok, [binary_to_list(X) || {X} <- L]};
        {error, Reason} ->
            {error, Reason}
    end.

%% ActionCB hcc-dns-update-action
action_cb(_Uinfo, [?ns|update], ?dns_ikp, _Params) ->
    case read_status() of
        {primary, _} ->
            case read_dns_config() of
                disabled ->
                    {error, ?CONFD_BUF(<<"dns is not enabled">>)};
                {error, Err} ->
                    write_nsupdate_status(1, Err),
                    {error, ?CONFD_BUF(Err)};
                DNS ->
                    {Code, Err} = nsupdate(DNS),
                    write_nsupdate_status(Code, Err),
                    {ok, []}
            end;
        _ ->
            {error, ?CONFD_BUF(<<"Not a primary node">>)}
    end;
%% ActionCB hcc-get-node-location-action
action_cb(_Uinfo, [?ns|'get-node-location'], ?dns_ikp, _Params) ->
    case node_id() of
        {ok, NodeId} ->
            Path_member = [{NodeId}, member | ?dns_ikp],
            with_cdb(
                fun(CDB)->
                    case ({ok, true} == econfd_cdb:exists(CDB, Path_member) andalso
                    {ok, true} == econfd_cdb:exists(CDB, [location | Path_member])) of
                    true ->
                        {ok, Location} = econfd_cdb:get_elem(CDB, [location | Path_member]),
                        {ok, [{[?ns|location], ?CONFD_BUF(Location)}]};
                    _ ->
                        {error, ?CONFD_BUF(<<"Unable to read /hcc/dns/member{", NodeId/binary,
                                "}/location">>)}
                    end
                end);
        _ ->
            {error, ?CONFD_BUF(<<"Could not identify local node's HA Id">>)}
    end.

%%--------------------------------------------------------------------
%% Update by reading latest configuration and cluster status and
%% taking any required actions e.g. taking/releasing VIP addresses.

update(State, Force, Event) ->
    case read_status() of
        {Role, PackageDir} ->
            update(State, Force, Role, PackageDir, Event);
        upgrading          ->
            State
    end.

% This update will b called when there is no change in role
update(#state{role = Role} = State, false = _Force, Role, _PackageDir, _Event) ->
    State;
update(State, _Force, Role, PackageDir, Event) ->
    State1 = State#state{
               vipctl = binary_to_list(PackageDir)++"/priv/vipctl"
              },
    State2 = case read_config() of
                 {enabled, VIPs, BGPConf} ->
                     BGP     = merge_bgp_state(State#state.bgp, BGPConf),
                     State1a = State1#state{ role = Role,
                                             vips = VIPs,
                                             bgp  = BGP
                                           },
                     case Role =:= primary of
                         true  -> vipctl(up, State1a);
                         false -> vipctl(down, State1a)
                     end;
                 disabled ->
                     %% Disabled in configuration
                     vipctl(down, State1),
                     State1#state{
                       role = disabled,
                       vips = [],
                       bgp  = disabled
                      }
             end,
    % New state, State2, has bgp enabled
    New_State = if is_record(State2#state.bgp, bgp) ->
            update_bgp(State2);
        % New state, State2, does not have bgp enabled, but it was enabled in earlier state i.e State#state.bgp
        % --> This means bgp must have been disabled, so stop earlier running one
       is_record(State#state.bgp, bgp) ->
            stop_bgp(State#state.bgp), % kill BGP daemon from old state rec
            State2;
        % No bgp before or in new state, may be just Vips
       true ->
            State2
    end,
    % DNS Update: If node is HA Primary and hcc/dns is enabled
    case Event of
        {econfd_notif_ha, ?CONFD_HA_INFO_IS_PRIMARY, _} ->
            case read_dns_config() of
                disabled -> noop;
                {error, Err} -> write_nsupdate_status(1, Err);
                DNS ->
                    {Code, Err} = nsupdate(DNS),
                    write_nsupdate_status(Code, Err)
            end;
        _ -> noop
    end,
    New_State.

%% Copy operational state into new BGP configuration record.
%%
%% (The #bgp and #neighbor records mix configuration data, that is
%% reset when NSO admin makes changes, with operational state, which
%% needs to be remembered. This function merges the latter into the
%% former.)
merge_bgp_state(#bgp{on_exit_port=OnExit,
                     port=Port,
                     ospid=Pid,
                     advertised=Adv,
                     neighbors=OldNs,
                     conf_path=ConfPath
                    }, BGPConf = #bgp{neighbors=ConfNs}) ->
    BGPConf#bgp{on_exit_port=OnExit, port=Port, ospid=Pid, advertised=Adv,
                neighbors = merge_bgp_neighbor_state(OldNs, ConfNs),
                conf_path=ConfPath};
merge_bgp_state(_, Conf) ->
    %% (no update without valid new and old configs)
    Conf.

%% preserve operational state of BGP connection into new config
merge_bgp_neighbor_state(OldNs, [N|ConfNs]) ->
    NewN = case lists:keysearch(N#neighbor.address, #neighbor.address, OldNs) of
               {value, OldN} ->
                   N#neighbor{state = OldN#neighbor.state};
               false ->
                   N
           end,
    [NewN | merge_bgp_neighbor_state(OldNs, ConfNs)];
merge_bgp_neighbor_state(_, []) ->
    [].

-spec read_config() -> disabled |
                       {enabled, VIPs :: [string()], BGP :: disabled | #bgp{}}.
read_config() ->
    with_cdb(
        fun(CDB)->
            case ({ok, true} == econfd_cdb:exists(CDB, ?hcc_ikp) andalso
                {ok, true} == econfd_cdb:get_elem(CDB, [enabled|?hcc_ikp])) of
                true ->
                    {ok, NVIPs} = econfd_cdb:num_instances(CDB, ['vip-address'
                                                                |?hcc_ikp]),
                    {ok, VIPs0} = econfd_cdb:get_objects(CDB,
                                                        ['vip-address'|?hcc_ikp],
                                                        0, NVIPs),
                    VIPs = [inet:ntoa(Addr) || Addr <- lists:flatten(VIPs0)],
                    BGP = case econfd_cdb:exists(CDB, [bgp|?hcc_ikp]) of
                            {ok, true} ->
                                read_bgp_config(CDB);
                            {ok, false} ->
                                disabled
                        end,
                    {enabled, VIPs, BGP};
                false ->
                    disabled
            end
        end).

find_executable(Name) ->
    case os:find_executable(Name) of
        false -> error({not_found, Name});
        Filename -> Filename
    end.

bgp_enabled(M, Th, Node) ->
    case ({ok, true} == econfd_maapi:get_elem(M, Th, [enabled|?hcc_ikp]) andalso
        {ok, true} == econfd_maapi:get_elem(M, Th, [enabled, Node, node, bgp|?hcc_ikp])) of
        true ->
            true;
        false ->
            disabled
    end.

with_cdb(Fun) ->
    {ok, S} = econfd_cdb:connect({127,0,0,1}, ?NCS_PORT),
    try
        econfd_cdb:wait_start(S),
        {ok, CDB} = econfd_cdb:new_session(
                      S, ?CDB_RUNNING, ?CDB_LOCK_REQUEST bor ?CDB_LOCK_WAIT),
        Fun(CDB)
    after
        econfd_cdb:close(S)
    end.

read_bgp_config(CDB) ->
    case node_id() of
        {ok, NodeId} ->
            read_bgp_config(CDB, NodeId);
        _Error ->
            disabled
    end.

read_bgp_config(CDB, NodeId) ->
    Key = [{NodeId}, node, bgp|?hcc_ikp],
    case ({ok, true} == econfd_cdb:exists(CDB, [enabled | Key]) andalso
          {ok, true} == econfd_cdb:get_elem(CDB, [enabled | Key])) of
        true ->
            {ok, ?CONFD_UINT32(AS)} = econfd_cdb:get_elem(CDB, [as | Key]),
            {ok, RouterID} = econfd_cdb:get_elem(CDB, ['router-id' | Key]),
            {ok, NumNeighbors} = econfd_cdb:num_instances(CDB,
                                                        [neighbor | Key]),
            Neighbors = [read_bgp_neighbor(CDB, NodeId, I)
                         || I <- lists:seq(0, NumNeighbors-1)],
            #bgp{enabled = true,
                 as = AS,
                 router_id = inet:ntoa(RouterID),
                 neighbors = Neighbors,
                 node_id = NodeId};
        false ->
            disabled
    end.

read_bgp_neighbor(CDB, NodeId, I) ->
    Key = [[I], neighbor, {NodeId}, node, bgp|?hcc_ikp],
    {ok, Address} = econfd_cdb:get_elem(CDB, [address|Key]),
    {ok, {_, AS}} = econfd_cdb:get_elem(CDB, [as|Key]),
    MinTTL = case econfd_cdb:get_elem(CDB, ['ttl-min' | Key]) of
                   {ok, {_, TTLMin}} -> TTLMin;
                   {error, _}        -> undefined
               end,
    MultihopTTL = case econfd_cdb:get_elem(CDB, ['multihop-ttl' | Key]) of
                   {ok, {_, TTLMultihop}} -> TTLMultihop;
                   {error, _}        -> undefined
               end,
    Password = case econfd_cdb:get_elem(CDB, [password | Key]) of
                   {ok, Pwd} -> binary_to_list(Pwd);
                   {error, _} -> undefined
               end,
    {ok, Enabled} = econfd_cdb:get_elem(CDB, [enabled | Key]),
    #neighbor{ enabled = Enabled,
               address = inet:ntoa(Address),
               as = AS,
               min_ttl = MinTTL,
               multihop_ttl = MultihopTTL,
               password = Password }.

%% Read operational status from MAAPI.
%% directory where helper script can be accessed.
%% read_status() -> {primary | secondary | disabled, PackageDir} | upgrading
read_status() ->
    try
        with_maapi_transaction(
          fun(M, Th) -> {role(M, Th), package_dir(M, Th)} end)
    catch
        error:{badmatch, {error, {?CONFD_ERR_BADSTATE, _}}} ->
            upgrading;
        error:{badmatch, {error, closed}} ->
            cast({event, force}),
            upgrading
    end.

role(M, Th) ->
    %% for debugging allow primary/secondary status to be forced
    case get(force_status) of
        primary   -> primary;
        secondary -> secondary;
        _         -> mode(M, Th)
    end.

mode(M, Th) ->
    Paths = [ [mode, ha, ['http://tail-f.com/yang/ncs-monitoring'|'ncs-state']],
              [mode, ha, ['http://tail-f.com/yang/ncs-monitoring2'|'ncs-state']]
            ],
    mode(M, Th, Paths).

mode(_M, _Th, []) ->
    disabled;
mode(M, Th, [Path | Paths]) ->
    case econfd_maapi:get_elem(M, Th, Path) of
        %% FIXME: 2 -> ?ncs_primary
        {ok, ?CONFD_ENUM_VALUE(2)} -> primary;
        {ok, _}                    -> secondary;
        _                          -> mode(M, Th, Paths)
    end.

package_dir(M, Th) ->
    Path = [ directory,
             {<<"tailf-hcc">>},
             package,
             ['http://tail-f.com/ns/ncs'|packages]
           ],
    {ok, PackageDir} = econfd_maapi:get_elem(M, Th, Path),
    PackageDir.

%% Return F(M, TH) where M is a maapi connection and TH is a maapi transction.
with_maapi_transaction(F) ->
    with_maapi_transaction(F, ?CONFD_RUNNING, ?CONFD_READ).

with_maapi_transaction(F, CDB, RWFlag) ->
    {ok, M} = econfd_maapi:connect({127,0,0,1}, ?NCS_PORT),
    try
        econfd_maapi:start_user_session(M, <<"">>, <<"system">>, [],
                                        {127,0,0,1}, ?CONFD_PROTO_TCP),
        {ok, TH} = econfd_maapi:start_trans(M, CDB, RWFlag),
        F(M, TH)
    after
        econfd_maapi:close(M)
    end.

%% Return unique identifier for this node.
node_id(M) ->
    case econfd_maapi:request_action(M, [], ['local-node-id'|?ncs_ha_ikp]) of
        {ok, [{[?ncs_ns|'id'], Bin}]} ->
            {ok, Bin};
        {error, _} = Error ->
            Error
    end.

node_id() ->
    with_maapi_transaction(fun(M, _) ->
        node_id(M)
    end).

%%%===================================================================
%%% econfd operational data callbacks
%%%===================================================================

init_trans(_Tx) ->
    ok.

get_elem(_Tx, ElemKey) ->
    NodeIKP = ['node', 'bgp'|?hcc_ikp],
    Req = case ElemKey of
              ['bgpd-pid', {NodeId}|NodeIKP] ->
                  {bgpd_pid, NodeId};
              ['bgpd-status', {NodeId}|NodeIKP] ->
                  {bgpd_pid, NodeId};
              ['state', {IP}, 'neighbor', {NodeId}|NodeIKP] ->
                  {neighbor_state, NodeId, inet:ntoa(IP)};
              ['connected', {IP}, 'neighbor', {NodeId}|NodeIKP] ->
                  {neighbor_state, NodeId, inet:ntoa(IP)};
              _ ->
                  {get_elem, ElemKey} %% this will be logged and return error
          end,
    case gen_server:call(?SERVER, Req) of
        undefined -> {ok, not_found};
        error     -> {ok, not_found};
        {pid, OSPid} when hd(ElemKey) == 'bgpd-pid' ->
            {ok, ?CONFD_UINT32(OSPid)};
        {pid, OSPid} when hd(ElemKey) == 'bgpd-status', is_integer(OSPid) ->
            {ok, <<"running">>};
        {pid, undefined} when hd(ElemKey) == 'bgpd-status' ->
            {ok, <<"not running">>};
        {state, NeighborState} when hd(ElemKey) == 'state' ->
            {ok, NeighborState};
        {state, NeighborState} when hd(ElemKey) == 'connected' ->
            {ok, NeighborState == <<"ESTABLISHED">>}
    end.

get_next(_Tx, _Path, _Idx) ->
    {ok, {false, undefined}}.

%%%===================================================================
%%% Layer-2 OS VIP management
%%%===================================================================

vipctl(Op, State) when is_port(State#state.on_exit_vipctl) ->
    %% If we have VIPs bound then synchronously clean them up first.
    complete_on_exit(State#state.on_exit_vipctl),
    vipctl(Op, State#state{on_exit_vipctl = undefined});
vipctl(_Op, #state{vips = []} = State) ->
    %% nothing to do
    State;
vipctl(up, #state{bgp = disabled} = State) ->
    %% Layer 2 case
    %% Bring VIPs up and install new cleanup action
    Port = on_exit(cmd_vipctl(State, ["down" | State#state.vips])),
    run_vipctl(State, ["up" | State#state.vips]),
    State#state{on_exit_vipctl = Port};
vipctl(up, State) ->
    %% Layer 3 case
    %% Bring VIPs up and install new cleanup action
    Port = on_exit(cmd_vipctl(State, ["down" | State#state.vips])),
    run_vipctl(State, ["up dev lo" | State#state.vips]),
    State#state{on_exit_vipctl = Port};
vipctl(down, State) ->
    %% Take VIPs down
    run_vipctl(State, ["down" | State#state.vips]),
    State.

run_vipctl(State, CommandLine) ->
    Cmd = cmd_vipctl(State, CommandLine),
    cmd(Cmd).

cmd_vipctl(#state{vipctl = VIPCTL}, CommandLine) ->
    lists:flatten([VIPCTL, [[" "++Arg] || Arg <- CommandLine]]).

%%%===================================================================
%%% OS commands
%%%===================================================================

cmd(S0) ->
    S = lists:flatten(S0),
    Res = os:cmd([S, "; echo -e \"\n$?\""]),
    case lists:reverse(Res) of
        "\n0\n"++_ ->
            econfd:log(?CONFD_LEVEL_TRACE, "~p: Command succeeded: ~s",
                       [?SERVER, S]),
            ok;
        _ ->
            econfd:log(?CONFD_LEVEL_ERROR, "~p: Got error result from ~s:~n~s",
                       [?SERVER, S, Res]),
            exit({command_failed, S, Res})
    end.

cmd_response(S0) ->
    S = lists:flatten(S0),
    CMD = [S, "; echo \"\n$?\""],
    Res = os:cmd(CMD),
    case lists:reverse(Res) of
        "\n0\n"++_ ->
            econfd:log(?CONFD_LEVEL_TRACE, "~p: nsupdate succeeded cmd:~p~n response: ~p",
                        [?SERVER, CMD, Res]),
            {0, []};
        _ ->
            econfd:log(?CONFD_LEVEL_ERROR, "~p: nsupdate cmd:~p~n response: ~p", [?SERVER, CMD, Res]),
            try
                [Code | T] = lists:reverse(string:tokens(Res, "\n")),
                {list_to_integer(Code), lists:join(" ", lists:reverse(T))}
            catch _:_ ->
                {182, "Unknown error"}
            end
    end.

%% open_exit(Cmd) -> Port
%% Schedule a command to automatically run when this Erlang process
%% (or this BEAM VM) terminates, or until explicitly canceled or
%% completed.
on_exit(Cmd) ->
    %% Spawn a port that executes Cmd iff stdin is closed with no input.
    %% (Writing any data to the port will disable the action.)
    %% FIXME find bash in PATH? use other available shells?
    open_port({spawn_executable, "/bin/bash"},
              [{args, ["-c", "read status; test -z \"$status\" &&" ++ Cmd]},
               use_stdio, eof]).

%% Cancel an on_exit action.
cancel_on_exit(Port) ->
    %% Write any data to the port's stdin to deactivate the action.
    erlang:port_command(Port, "cancel\n"),
    catch erlang:port_close(Port),
    %% Catch the exit message sent on port close.
    receive {'EXIT', Port, _} -> ok
    after 0 -> ok
    end.

complete_on_exit(Port) ->
    %% Close port without data to activate the cleanup action
    catch erlang:port_close(Port),
    %% Catch the exit message sent on port close.
    receive {'EXIT', Port, _} -> ok
    after 0 -> ok
    end.

%%%===================================================================
%%% BGP daemon management
%%%===================================================================

%% Have to start/update BGP
update_bgp(#state{bgp = BGP0} = State) when BGP0#bgp.enabled == true ->
    BGP1 = write_bgp_config(BGP0),
    BGP2 = if BGP1#bgp.port == undefined ->
                   start_bgp(BGP1);
              true ->
                   hup_bgp(BGP1)
           end,
    advertise_routes(State#state{bgp = BGP2}).

%% Update advertised routes by adding new and removing old.
advertise_routes(State = #state{role = Role, bgp = BGP}) ->
    GoBGP = find_executable("gobgp"),
    NewVIPs = case Role of
                  primary -> State#state.vips;
                  _       -> []
              end,
    OldVIPs = (State#state.bgp)#bgp.advertised,
    advertise_routes(GoBGP, NewVIPs, OldVIPs),
    State#state{bgp = BGP#bgp{advertised = NewVIPs}}.

advertise_routes(GoBGP, NewVIPs, OldVIPs) ->
    Add = NewVIPs -- OldVIPs,
    Del = OldVIPs -- NewVIPs,
    lists:foreach(fun(VIP) -> update_route(GoBGP, "add", VIP) end, Add),
    lists:foreach(fun(VIP) -> update_route(GoBGP, "del", VIP) end, Del).

update_route(GoBGP, AddOrDel, VIP) ->
    Cmd = case lists:member($:, VIP) of
              false ->
                  "global rib "++AddOrDel++" -a ipv4 "++VIP++"/32";
              true ->
                  "global rib "++AddOrDel++" -a ipv6 "++VIP++"/128"
          end,
    cmd(GoBGP ++ " " ++ Cmd).

%% Make BGP daemon load updated configuration
hup_bgp(BGP) ->
    os:cmd("kill -HUP " ++ integer_to_list(BGP#bgp.ospid)),
    BGP.

%% Start BGP daemon
start_bgp(#bgp{conf_path=Conf} = BGP) ->
    GoBGPD = find_executable("gobgpd"),
    Port = open_port({spawn_executable, GoBGPD},
                     [{args, ["-l", "debug", "-f", Conf]},
                      {line, 20480},
                      stderr_to_stdout,
                      exit_status]),
    {os_pid, OSPid} = erlang:port_info(Port, os_pid),
    %% Note: GoBGPD does not automatically terminate when stdin closes.
    OnExitPort = on_exit(kill(OSPid) ++ "; " ++ rm_f(Conf)),
    wait_bgp_started(Port),
    BGP#bgp{port = Port, ospid = OSPid, on_exit_port = OnExitPort}.

kill(OSPid) when is_integer(OSPid) ->
    "kill -9 " ++ integer_to_list(OSPid).

rm_f(Path) when is_list(Path) ->
    "rm -f " ++ Path.

%% Block until BGP daemon is ready for commands
wait_bgp_started(Port) ->
    receive
        {Port, {data, Data}} ->
            {eol, Line} = Data,
            Log = input_bgp_line(Line),
            case includes(Log, [{"Topic", "Config"},
                                {"level", "info"},
                                {"msg", "Finished reading the config file"}]) of
                true ->
                    ok;
                false ->
                    wait_bgp_started(Port)
            end;
        {Port, Err = {exit_status, _}} ->
            {error, {start_bgpd, Err}}
    after 10000 ->
            exit(bgpd_started_timeout)
    end.

maybe_stop_bgp(disabled)             -> ok;
maybe_stop_bgp(#bgp{port=undefined}) -> ok;
maybe_stop_bgp(BGP)                  -> stop_bgp(BGP).

%% Terminate BGP daemon
stop_bgp(BGP) when BGP#bgp.port /= undefined ->
    BGP#bgp.port ! {self(), close},
    complete_on_exit(BGP#bgp.on_exit_port),
    BGP#bgp{port = undefined, ospid = undefined, conf_path=undefined}.

%%%===================================================================
%%% bgp daemon output processing
%%%===================================================================

%% Parse and log a line of (JSON) output from gobgpd.
input_bgp_line(Line) ->
    case json2:decode_string(Line) of
        {ok, {struct, Struct}} ->
            log_bgp_line(Line, Struct),
            Struct;
        {error, Reason} ->
            econfd:log(?CONFD_LEVEL_TRACE,
                       "~p: gobgpd output failed to parse (~p): ~s",
                       [?SERVER, Reason, Line]),
            [] %% no JSON attributes
    end.

log_bgp_line(Line, Struct) ->
    Level = case lists:keysearch(level, 1, Struct) of
                {value, {level, "panic"}} -> ?CONFD_LEVEL_ERROR;
                {value, {level, "fatal"}} -> ?CONFD_LEVEL_ERROR;
                {value, {level, "error"}} -> ?CONFD_LEVEL_ERROR;
                {value, {level, "warn"}}  -> ?CONFD_LEVEL_INFO;
                {value, {level, "info"}}  -> ?CONFD_LEVEL_INFO;
                _                         -> ?CONFD_LEVEL_TRACE
            end,
    econfd:log(Level, "~p: gobgpd output: ~s", [?SERVER, Line]).

%% Check if Have includes (is a superset of) Expected.
includes(Have, Expected) ->
    Expected -- Have == [].

%% Parse and log a line of output from gobgpd and also scan the
%% contents for state updates.
input_bgp_event(BGP, Line) ->
    Log = input_bgp_line(Line),
    BGP1 = case includes(Log, [{"Topic","Peer"}, {"msg","state changed"}]) of
               true ->
                   {value, {_, IP}} = lists:keysearch("Key", 1, Log),
                   {value, {_, St}} = lists:keysearch("new", 1, Log),
                   set_neighbor_state(BGP, IP, St);
               false ->
                   BGP
           end,
    BGP1.

set_neighbor_state(BGP = #bgp{neighbors = Ns0}, IP, State) ->
    {value, N0} = lists:keysearch(IP, #neighbor.address, Ns0),
    ConnectionState = bgp_state_name(State),
    N1 = N0#neighbor{state = ConnectionState},
    Ns1 = lists:keyreplace(IP, #neighbor.address, Ns0, N1),
    BGP#bgp{neighbors = Ns1}.

%% Shorten BGP state name reported by GoBGP.
bgp_state_name("BGP_FSM_"++State) -> State;
bgp_state_name(State)             -> State.

%%%===================================================================
%% gobgpd configuration file generation.
%%%===================================================================

%% Generate configuration file for BGP daemon.
%% Does not support VIP route definitions. Not supported in GoBGP
%% configuration file. Have to be added separately.
write_bgp_config(#bgp{conf_path=undefined} = BGP) ->
    write_bgp_config(BGP#bgp{conf_path = bgp_config_path()});
write_bgp_config(#bgp{conf_path=Path} = BGP) ->
    Conf = gobgp_config_string(BGP),
    ok = atomic_write_file(Path, Conf),
    BGP.

bgp_config_path() -> "/tmp/bgp." ++ random_string() ++ ".conf".

random_string() ->
    random_string("", 10).

random_string(Acc, 0) ->
    Acc;
random_string(Acc0, N) ->
    Acc = [char(rand:uniform(char_max()))|Acc0],
    random_string(Acc, N-1).

char(N) when N >= 1, N < 27 -> $a+N-1;
char(N) when N < 37         -> $0+N-27.
char_max()                  -> 36.

%% Write a file atomically i.e. without risk that somebody will see
%% the data before it is fully written.
atomic_write_file(Path, IOList) ->
    Tmp = Path ++ ".tmp",
    ok = file:write_file(Tmp, IOList),
    ok = file:rename(Tmp, Path).

%% Return GoBGP daemon config as a string.
gobgp_config_string(BGP) ->
    [ gobgp_global(BGP),
      lists:map(fun gobgp_neighbor/1, BGP#bgp.neighbors)
    ].

%% Return global section of GoBGP configuration.
gobgp_global(BGP) ->
    [ "[global.config]\n",
      "  as = ", erlang:integer_to_list(BGP#bgp.as), "\n",
      "  router-id = \"", BGP#bgp.router_id, "\"\n"
    ].

%% Return a neighbor section of GoBGP configuration.
gobgp_neighbor(N) ->
    [ "[[neighbors]]\n",
      "  [neighbors.config]\n",
      "    neighbor-address = \"", N#neighbor.address, "\"\n",
      "    peer-as = ", erlang:integer_to_list(N#neighbor.as), "\n",
      password(N),
      ttl_min(N),
      ttl_multihop(N),
      %% Advertise both IPv4 and IPv6 routes
      "  [[neighbors.afi-safis]]\n",
      "    [neighbors.afi-safis.config]\n",
      "      afi-safi-name = \"ipv4-unicast\"\n",
      "  [[neighbors.afi-safis]]\n",
      "    [neighbors.afi-safis.config]\n",
      "      afi-safi-name = \"ipv6-unicast\"\n"
    ].

password(#neighbor{password = undefined}) ->
    "";
password(#neighbor{password = Password}) ->
    ["    auth-password = \"", Password, "\"\n"].

ttl_min(#neighbor{min_ttl = undefined}) ->
    "";
ttl_min(#neighbor{min_ttl = TtlMin}) ->
      [ "  [neighbors.ttl-security.config]\n",
        "    enabled = true\n",
        "    ttl-min = ", erlang:integer_to_list(TtlMin), "\n"
      ].

ttl_multihop(#neighbor{multihop_ttl = undefined}) ->
    "";
ttl_multihop(#neighbor{multihop_ttl = TtlMultihop}) ->
      [ "  [neighbors.ebgp-multihop.config]\n",
        "    enabled = true\n",
        "    multihop-ttl = ", erlang:integer_to_list(TtlMultihop), "\n"
      ].

%%%===================================================================
%%% DNS Update
%%%===================================================================

%% Read DNS information
-spec read_dns_config() -> DNS :: disabled | #dns{} | {error, string()}.
read_dns_config() ->
    with_cdb(
        fun(CDB)->
            case ({ok, true} == econfd_cdb:get_elem(CDB, [enabled|?hcc_ikp]) andalso
                    {ok, true} == econfd_cdb:get_elem(CDB, [enabled|?dns_ikp])) of
                true ->
                    read_dns_config(CDB);
                false ->
                    disabled
            end
        end).

read_dns_config(CDB) ->
    NodeIPs = node_ips(),
    case NodeIPs of
        {error, _} = Error ->
            Error;
        _ ->
            {ok, Fqdn} = econfd_cdb:get_elem(CDB, [fqdn | ?dns_ikp]),
            {ok, ?CONFD_UINT32(TTL)} = econfd_cdb:get_elem(CDB, [ttl | ?dns_ikp]),
            Server = case econfd_cdb:get_elem(CDB, [server | ?dns_ikp]) of
                {ok, V} -> inet:ntoa(V);
                {error, _} -> undefined
            end,
            {ok, ?CONFD_UINT32(Port)} = econfd_cdb:get_elem(CDB, [port | ?dns_ikp]),
            Zone = cdb_get_elem_default(CDB, [zone | ?dns_ikp], undefined),
            Key_File = cdb_get_elem_default(CDB, ['key-file' | ?dns_ikp], undefined),
            {ok, ?CONFD_UINT32(Timeout)} = econfd_cdb:get_elem(CDB, [timeout | ?dns_ikp]),
            #dns{enabled = true,
                node_ip = [inet:ntoa(IP) || IP <- NodeIPs],
                fqdn = Fqdn,
                ttl = TTL,
                key_file = Key_File,
                server = Server,
                port = Port,
                zone = Zone,
                timeout = Timeout
             }
    end.

node_ips() ->
    with_maapi_transaction(fun(M, TH) ->
        case node_id(M) of
            {ok, NodeId} ->
                Path_IP =  ['ip-address', {NodeId}, member | ?dns_ikp],
                {ok, IPs} = econfd_maapi:all_keys(M, TH, Path_IP),
                [X || {X} <- IPs];
            _ ->
                {error, "Could not identify local node's HA Id"}
        end
      end).

%% Preapare nsupdate commands and update DNS
nsupdate(DNS) ->
    econfd:log(?CONFD_LEVEL_TRACE, "~p: DNS record: ~p", [?SERVER, DNS]),
    nsupdate_execute(nsupdate_prepare_rr(DNS), nsupdate_cmd(DNS)).

nsupdate_prepare_rr(DNS) ->
    [ nsupdate_server(DNS)
        , nsupdate_zone(DNS)
        , nsupdate_delete_record(DNS)
        , nsupdate_add_record(DNS)
        , nsupdate_send()
    ].

nsupdate_send() ->
    ["send", "\n", "quit"].

nsupdate_server(#dns{server=Server, port=Port}) ->
    case Server of
        undefined -> [];
        _ -> [ "server ", Server, " ", integer_to_list(Port), " \n" ]
    end.

nsupdate_zone(#dns{zone = Zone}) ->
    case Zone of
        undefined -> [];
        _ -> [ "zone ", Zone , " \n" ]
    end.

nsupdate_delete_record(#dns{fqdn=FQDN}) ->
    [ "update delete ", FQDN, " AAAA", "\n",
        "update delete ", FQDN, " A", "\n" ].

nsupdate_add_record(#dns{fqdn=FQDN, ttl=TTL, node_ip=NodeIp}) ->
    add_record(FQDN, TTL, NodeIp, []).

add_record(_FQDN, _TTL, [], Acc) ->
    Acc;
add_record(FQDN, TTL, [IP|T], Acc) ->
    Record_Type = case lists:member($:, IP) of
                        false -> " A ";     % IPv4
                        true -> " AAAA "    % IPv6
                    end,
    add_record(FQDN, TTL, T,
                [[ "update add ", FQDN, " ", integer_to_list(TTL), Record_Type, IP, "\n" ] | Acc]).

nsupdate_cmd(#dns{key_file = KeyFile, timeout = Timeout}) ->
    ["nsupdate -t ", integer_to_list(Timeout)]
      ++ case KeyFile of
            undefined -> [" "];
            _ -> [" -k ", binary_to_list(KeyFile), " "]
         end.

nsupdate_execute(NSUpdate, Cmd) ->
    File_Name = nsupdate_config_path(),
    ok = atomic_write_file(File_Name, NSUpdate),
    Res = cmd_response(Cmd ++ [File_Name]),
    delete_temp_files("nsupdate_*.txt"),
    Res.

-spec write_nsupdate_status(Code :: integer(), Error :: string()) -> ok.
write_nsupdate_status(Code, Error) ->
    with_maapi_transaction(
        fun(M, TH) ->
            try
                Path = [status|?dns_ikp],
                ok = econfd_maapi:set_elem(M, TH, [time|Path],
                                            ?CONFD_DATETIME(get_current_datetime())),
                ok = econfd_maapi:set_elem(M, TH, ['exit-code'|Path], ?CONFD_UINT32(Code)),
                case Error of
                    [] -> econfd_maapi:delete(M, TH, ['error-message'|Path]);
                    _ -> ok = econfd_maapi:set_elem(M, TH, ['error-message'|Path],
                                            list_to_binary(Error))
                end,
                econfd_maapi:apply_trans(M, TH, false),
                ok
            catch
                X:Y:StackTrace ->
                    econfd:log(?CONFD_LEVEL_ERROR,
                        "~p: Failed to update nsupdate status~p:~p\n~p",
                        ?SERVER,
                                [X,Y,StackTrace])
            end
         end,
        ?CONFD_OPERATIONAL, ?CONFD_READ_WRITE).

nsupdate_config_path() -> "/tmp/nsupdate_" ++ random_string() ++ ".txt".

delete_temp_files(WildCard) ->
    lists:map(fun(FileName) ->
                    io:fwrite("Deleting File:~p~p~n ",["/tmp/",FileName]),
                    file:delete(["/tmp/", FileName])
                end,
              filelib:wildcard(WildCard,"/tmp/")).

cdb_get_elem_default(CDB, Path, Default) ->
    try
        {ok, V} = econfd_cdb:get_elem(CDB, Path),
        V
    catch _:_ ->
        Default
    end.

get_current_datetime() ->
    {_, _, Micro} = Now = erlang:timestamp(),
    {{YYYY,MM,DD},{HH,Min,SS}} = calendar:now_to_datetime(Now),
    {YYYY,MM,DD,HH,Min,SS,Micro,0,0}.
