"""
 upgrade script for resource-manager from 3.5.6(or any version <4.0.0) to version 4.0.0 or above
 This upgrade script is configured in the  package-meta-data.xml file and 
  will be triggered automatically  in the package upgrading process. 

 User can also manaually run the script on command Line.


The resource-manager 4.0.0 operational data model is not compapatible with previous version,
in version 4.0.0 yang model, there is a new element "allocationId" for /id-allocator/pool/allocation needed to support sync allocation.

upgrade steps:
  1) iterate all the resource-pools/id-pool 
  2) for each id-pool , log all the allocatons under the pool , and  iterate all allocations for this pool
  3) for each resource-pools/id-pool/allocation, check if it is successfully allocated (alloc.response.id not empty),
        if true, then set the new element allocationId to the responseId (alloc.response.id)
        ( idpool_id_allocator.allocation[responseId].allocationId = alloc.id )

Important:
    After run the script from commandLine, we must request package reload or restart ncs to reload new CBD data into ID Pool java object in memory.
    For example, in nso-cli console, admin@ncs> request packages reload force

"""


import ncs
import _ncs

class RMUpgrade(ncs.upgrade.Upgrade):
    def upgrade(self, cdbsock, trans):
        _ncs.cdb.start_session2(cdbsock, ncs.cdb.RUNNING,
                                                   ncs.cdb.LOCK_SESSION | ncs.cdb.LOCK_WAIT)

        try:
            if not _ncs.cdb.exists(cdbsock, "/ralloc:resource-pools"):
                print("No upgrade needed. No previous RM version.")
                return True

            rm_upgrade(trans)
        except Exception as err:
            err_str = str(err)
            if "nonexistent path" in err_str or "No such namespace" in err_str:
                print(f"No upgrade needed. No previous RM version.")
                return True
            raise err

        return True


def rm_upgrade(t):
    print("rm_upgrading for id_allocator")
    root = ncs.maagic.get_root(t)
    for idpool in root.resource_pools.id_pool:
        print('poolName = {}'.format(idpool.name))
        if idpool.name not in root.id_allocator.pool:
            print("[warning]pool not exist : " + idpool.name)
            continue
        idpool_id_allocator = root.id_allocator.pool[idpool.name]
        for oper_allocation in idpool_id_allocator.allocation:
             print('   oper allocation = {}, allocationId = {}'.format(oper_allocation.id,oper_allocation.allocationId))
        print();
        for alloc in idpool.allocation:
            print('   config allocation = {}, responseId = {}'.format(alloc.id,alloc.response.id))
            if alloc.response and alloc.response.id :
                responseId = alloc.response.id
                if responseId in idpool_id_allocator.allocation:
                    if idpool_id_allocator.allocation[responseId].allocationId == None:
                        idpool_id_allocator.allocation[responseId].allocationId = alloc.id
                        print("       update oper allocation= {} ,  allocationId = {}".format(responseId, alloc.id))
                    else:
                        print("        no update")
                else:
                    print("    [warning]No allocationId found in oper allocation: {} ".format(responseId))
            else:
                print("    [warning]no response/id found for allocation " + alloc.id)
                

def rm_upgrade_cmd():

    with ncs.maapi.Maapi(ip='127.0.0.1',port = ncs.NCS_PORT) as m:
        with ncs.maapi.Session(m, 'admin', 'system'):
            with m.start_write_trans() as t:
                rm_upgrade(t)
                t.apply()


if __name__ == '__main__':
    rm_upgrade_cmd()
