package com.tailf.pkg.ipaddressallocator;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import org.apache.log4j.Logger;
import com.tailf.cdb.CdbSession;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfIP;
import com.tailf.conf.ConfList;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfPath;
import com.tailf.conf.ConfUInt8;
import com.tailf.conf.ConfValue;
import com.tailf.pkg.ipaddressallocator.namespaces.ipaddressAllocatorOper;
import com.tailf.pkg.ipam.Allocation;
import com.tailf.pkg.ipam.Subnet;


public class AllocationsSet extends HashSet<Allocation> {

    private static final long serialVersionUID = 0;
    private static final Logger LOGGER = Logger.getLogger(AllocationsSet.class);

    private CdbSession wsess;
    public String poolName;
    public String poolPath;

    private ConfPath allocPath;

    public AllocationsSet(String poolName) {
        super();
        this.poolName = poolName;
        try {
            this.allocPath = new ConfPath("/%s:%s/%s{\"%s\"}/%s", ipaddressAllocatorOper.prefix,
                ipaddressAllocatorOper._ip_allocator_, ipaddressAllocatorOper._pool_, poolName,
                ipaddressAllocatorOper._allocation_);
        } catch (ConfException e) {
            LOGGER.error("Failed to setup up allocationsSet", e);
        }
    }

    public AllocationsSet(CdbSession wsess, String poolName) {
        super();

        this.wsess = wsess;
        this.poolName = poolName;

        /* Populate from allocations stored in CDB oper data */

        try {
            this.allocPath = new ConfPath("/%s:%s/%s{\"%s\"}", ipaddressAllocatorOper.prefix,
                ipaddressAllocatorOper._ip_allocator_, ipaddressAllocatorOper._pool_, poolName);

            /* We have configured a pool but it isn't set up in oper data yet. */
            if (wsess.exists(this.allocPath) == false) {
                LOGGER.debug("Operational pool missing, creating.");
                wsess.create(this.allocPath);
            }

            this.allocPath.append(ipaddressAllocatorOper._allocation_);

            int n = wsess.getNumberOfInstances(this.allocPath);
            if (n > 0) {
                List<ConfObject[]> objs = wsess.getObjects(6, 0, n, this.allocPath);

                for (ConfObject[] obj : objs) {
                    String address = ((ConfIP) obj[0]).toString();
                    int mask = (int) ((ConfUInt8) obj[1]).longValue();
                    ConfValue ownersConf = (ConfValue) obj[3];
                    String username = ((ConfBuf) obj[4]).toString();
                    String requestId = ((ConfBuf) obj[5]).toString();
                    Subnet sub = new Subnet(address, mask);
                    List<String> owners = new ArrayList<String>();

                    if (ownersConf instanceof ConfList) {
                        ConfObject ownerPaths[] = ((ConfList) ownersConf).elements();

                        for (ConfObject path : ownerPaths) {
                            owners.add(((ConfBuf) path).toString());
                        }
                    }

                    super.add(new Allocation(sub, owners, username, requestId));
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to setup up allocationsSet", e);
        }
    }

    public String getAllocationsPath() {
        return this.allocPath.toString();
    }

    @Override
    public boolean add(Allocation e) {
        boolean res = super.add(e);
        return res;
    }

    @Override
    public boolean remove(Object o) {
        boolean res = super.remove(o);
        return res;
    }

    @Override
    public void clear() {
        super.clear();
    }

    public void addToCdb(Allocation e) {
        try {
            Subnet sub = e.getAllocated();
            String x = String.format("%s{%s %s}", this.allocPath.toString(), sub.getAddress()
                .getHostAddress(), Integer.toString(sub.getCIDRMask()));
            this.wsess.create(x);

            List<String> occupants = e.getOccupants();
            String owner = !occupants.isEmpty() ? occupants.get(0) : "";
            this.wsess.setElem(new ConfBuf(owner), new ConfPath(x + "/"
                + ipaddressAllocatorOper._owner_));

            for (String occupant : occupants) {
                ConfPath ownerElem = new ConfPath("%s/%s{%x}", x, ipaddressAllocatorOper._owners_,
                    new ConfBuf(occupant));
                this.wsess.create(ownerElem);
            }
            this.wsess.setElem(new ConfBuf(e.getUsername()), new ConfPath(x + "/"
                + ipaddressAllocatorOper._username_));
            this.wsess.setElem(new ConfBuf(e.getRequestId()), new ConfPath(x + "/"
                + ipaddressAllocatorOper._request_id_));
        } catch (Exception ex) {
            LOGGER.error("Error adding allocation to pool", ex);
        }
    }

    public void addOwnersToCdb(Allocation e) {
        try {
            Subnet sub = e.getAllocated();
            String x = String.format("%s{%s %s}", this.allocPath.toString(), sub.getAddress()
                .getHostAddress(), Integer.toString(sub.getCIDRMask()));

            List<String> occupants = e.getOccupants();
            String owner = !occupants.isEmpty() ? occupants.get(0) : "";
            this.wsess.setElem(new ConfBuf(owner), new ConfPath(x + "/"
                + ipaddressAllocatorOper._owner_));

            String owners = x + "/" + ipaddressAllocatorOper._owners_;
            if (this.wsess.exists(owners)) {
                this.wsess.delete(owners);
            }
            for (String occupant : occupants) {
                ConfPath ownerElem = new ConfPath("%s{%x}", owners, new ConfBuf(occupant));
                this.wsess.create(ownerElem);
            }
        } catch (Exception ex) {
            LOGGER.error("Error adding owners to allocation", ex);
        }
    }

    public void removeFromCdb(Object o) {
        try {
            Allocation e = (Allocation) o;
            Subnet sub = e.getAllocated();
            String x = String.format("%s{%s %s}", this.allocPath.toString(), sub.getAddress()
                .getHostAddress(), Integer.toString(sub.getCIDRMask()));
            if (this.wsess.exists(x)) {
                this.wsess.delete(x);
            }
        } catch (Exception ex) {
            LOGGER.error("Error removing allocation from pool", ex);
        }
    }

    /*public void clearFromCdb() {
        try {
            if (this.wsess.exists(this.allocPath) && this.wsess.getNumberOfInstances(
                this.allocPath) > 0) {
                this.wsess.delete(this.allocPath);
            }
        } catch (Exception ex) {
            LOGGER.error("Error clearing pool", ex);
        }
    }*/
}
