package com.example.vlan;

import java.net.InetAddress;
import java.net.Socket;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.tailf.conf.Conf;
import com.tailf.conf.ConfIPPrefix;
import com.tailf.conf.ConfXMLParam;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.annotations.ServiceCallback;
import com.tailf.dp.proto.ServiceCBType;
import com.tailf.dp.services.ServiceContext;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.navu.NavuException;
import com.tailf.navu.NavuNode;
import com.tailf.ncs.template.Template;
import com.tailf.ncs.template.TemplateVariables;
import com.tailf.pkg.ipaddressallocator.IPAddressAllocator;
import com.tailf.pkg.resourcemanager.RedeployType;


public class vlanRFS {
    private static Logger logger = LogManager.getLogger(vlanRFS.class);


    /**
     * Create callback method. This method is called when a service instance committed due to a
     * create or update event.
     *
     * This method returns a opaque as a Properties object that can be null. If not null it is
     * stored persistently by Ncs. This object is then delivered as argument to new calls of the
     * create method for this service (fastmap algorithm). This way the user can store and later
     * modify persistent data outside the service model that might be needed.
     *
     * @param context - The current ServiceContext object
     * @param service - The NavuNode references the service node.
     * @param ncsRoot - This NavuNode references the ncs root.
     * @param opaque - Parameter contains a Properties object. This object may be used to transfer
     *        additional information between consecutive calls to the create callback. It is always
     *        null in the first call. I.e. when the service is first created.
     * @return Properties the returning opaque instance
     * @throws DpCallbackException
     */

    @ServiceCallback(servicePoint = "allocating-service-servicepoint",
        callType = ServiceCBType.CREATE)
    public Properties create(ServiceContext context, NavuNode service, NavuNode ncsRoot,
        Properties opaque) throws DpCallbackException {


        logger.info("vlanRFS -----create()");
        /*
         * String servicePath = null; String actionValue = triggerAction(service);
         * logger.info("actionValue returned = "+actionValue);
         */



        try {
            String srvcname = service.leaf("name").valueAsString();
            String pool = service.leaf("pool").valueAsString();
            String allocid = service.leaf("ipv4").valueAsString();
            String subsize = service.leaf("subnet-size").valueAsString();
            // String dev = service.leaf("device").valueAsString();

            IPAddressAllocator.subnetRequest(service, RedeployType.REACTIVE_REDEPLOY, pool, "admin",
                "", Integer.parseInt(subsize), allocid, false, true);
            boolean ready = IPAddressAllocator.responseReady(service.context(), pool, allocid);
            logger.info("vlanRFS -----create() ready " + ready);
            if (ready) {
                ConfIPPrefix ipvalue = IPAddressAllocator.subnetRead(service.context(), pool,
                    allocid);
                logger.info("vlanRFS -----create() ipvalue " + ipvalue.toString());
                Template vlanTemplate = new Template(context, "ip-allocated");
                TemplateVariables vlanVar = new TemplateVariables();
                vlanVar.putQuoted("ALLOCATED", ipvalue.toString());
                vlanVar.putQuoted("OWNER", service.getKeyPath());
                vlanTemplate.apply(service, vlanVar);

                // Template vlanTemplate = new Template(context, "device");
                // TemplateVariables vlanVar = new TemplateVariables();
                // vlanVar.putQuoted("SERVICE", srvcname);
                // vlanVar.putQuoted("DEVICE_NAME", dev);
                // vlanVar.putQuoted("IP", ipvalue.toString());
                // vlanTemplate.apply(service, vlanVar);
            }

        } catch (Exception e) {
            throw new DpCallbackException("Cannot create service ", e);
        }
        return opaque;
    }

    public void firstAction() throws DpCallbackException {
        logger.info("firstAction-point action()");

        try {
            Socket socket = new Socket("localhost", Conf.NCS_PORT);
            Maapi maapi = new Maapi(socket);
            maapi.startUserSession("admin", InetAddress.getByName("localhost"), "maapi",
                new String[] {"admin"}, MaapiUserSessionFlag.PROTO_TCP);


            ConfXMLParam[] qtcmRes = maapi.requestAction(new ConfXMLParam[] {},
                "/nso-actions/testAction");

        } catch (Exception ex) {
            logger.error("firstAction failed", ex);

        }
        logger.info("firstActin done");

    }

    public String triggerAction(NavuNode service) throws DpCallbackException {
        logger.info("triggerAction action()");
        String result = "-1";
        try {
            Maapi maapi = service.context().getMaapi();
            ConfXMLParam[] res = maapi.requestAction(new ConfXMLParam[] {},
                "/test-actions/myAction");

            for (ConfXMLParam p : res) {
                logger.info("res tag " + p.getTag());
                logger.info("res value " + p.getValue());
                if (p.getTag().equalsIgnoreCase("result")) {

                    result = p.getValue().toString();

                }

            }

            String out1 = ConfXMLParam.toXML(res);
            // logger.info("out1 = "+out1);

            String out2 = ConfXMLParam.toXML(res, "output", "/test-actions/myAction");
            // logger.info("out2 = "+out2);


        } catch (Exception ex) {
            logger.error("triggerAction failed", ex);

        }

        logger.info("triggerAction done");

        return result;

    }

    public void findMatchVirtoOper() {


    }

    private boolean virtooperExist(NavuNode ncsRoot, String deviceName) throws NavuException {
        logger.info("deviceExist  deviceName =  " + deviceName);
        String query = "device[name='" + deviceName + "']";
        List<NavuNode> matchNodes = ncsRoot.container("devices").xPathSelect(query);
        return (matchNodes != null && matchNodes.size() == 1);

    }

}
