package com.tailf.pkg.nsoutil;



import java.net.Socket;
import java.util.EnumSet;
import org.apache.log4j.Logger;
import com.tailf.conf.Conf;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.ncs.ApplicationComponent;
import com.tailf.ncs.annotations.Resource;
import com.tailf.ncs.annotations.ResourceType;
import com.tailf.ncs.annotations.Scope;
import com.tailf.notif.HaNotification;
import com.tailf.notif.Notif;
import com.tailf.notif.Notification;
import com.tailf.notif.NotificationType;


public class HaNotificationRev implements ApplicationComponent {
    private static final Logger LOGGER = Logger.getLogger(HaNotificationRev.class);
    private Socket notif_sock = null;
    private Notif notif = null;
    @Resource(type = ResourceType.MAAPI, scope = Scope.INSTANCE,
            qualifier = "HaNotificationRev-m")
    private Maapi maapi;
    private int tid;
 

    @Override
    public void init() throws Exception {
    	 LOGGER.info("HaNotificationRev init()"); 
         maapi.startUserSession("admin", maapi.getSocket().getInetAddress(), "system", new String[] {
         	"admin"}, MaapiUserSessionFlag.PROTO_TCP);
         tid = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);
         notif_sock = new Socket("127.0.0.1", Conf.NCS_PORT);
         notif = new Notif(notif_sock,
                      EnumSet.of(NotificationType.NOTIF_HA_INFO));
        
    }

    @Override
    public void finish() {
        try {
            notif_sock.close();
            maapi.finishTrans(tid);
            maapi.getSocket().close();
           
        } catch (Exception igone) {
        }
    }

    @Override
    public void run() {
        LOGGER.info("HaNotificationRev start running...");
        while (true) {
			Notification n;
			try {
				n = notif.read();				
				
			} catch (Exception e) {
				LOGGER.error("notif.read() "+ e.getMessage());
				return;
			}
			if (n instanceof HaNotification ) {
				LOGGER.info("[HaNotificationRev] receive notification " + ((HaNotification)n));
				NSOUtil.updateHaPrimary(maapi, tid);
				
			}							 
        	
        }

    }


}
