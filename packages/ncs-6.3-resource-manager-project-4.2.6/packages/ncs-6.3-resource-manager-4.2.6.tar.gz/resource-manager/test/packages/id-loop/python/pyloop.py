import ncs
import _ncs
from ncs.application import Service
import _ncs.cdb as cdb
import resource_manager.id_allocator as id_allocator
import socket


class LoopService(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Service create(service=', service._path, ')')
        pool_name = service.pool
        alloc_name = service.allocation_name if service.allocation_name else service.name
        sock = socket.socket()

        # Update 'deploys' oper data count
        cdb.connect(sock, type=cdb.DATA_SOCKET, ip='127.0.0.1', port=_ncs.NCS_PORT)
        cdb.start_session(sock, db=cdb.OPERATIONAL)
        deploy_path = "/services/id-loop-python{{{}}}/deploys".format(service.name)
        deploys  = 1

        if cdb.exists(sock, deploy_path):
            deploys = cdb.get(sock, deploy_path).as_pyval()

        if cdb.exists(sock, service._path):
            cdb.set_elem(sock, str(deploys + 1), deploy_path)

        cdb.end_session(sock)
        cdb.close(sock)

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-python[name='%s']" % (service.name),
                                tctx.username,
                                pool_name,
                                alloc_name,
                                False,-1,"default",False,root)

        id = id_allocator.id_read(tctx.username, root,
                                  pool_name, alloc_name)
        if not id:
            self.log.info("Alloc1 not ready")
            return

        self.log.info('id1 = %s' % (id))

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-python[name='%s']" % (service.name),
                                tctx.username,
                                pool_name,
                                "specific_id",
                                False,
                                20,"default",False,root)

        id = id_allocator.id_read(tctx.username, root,
                                  pool_name, "specific_id")
        if not id:
            self.log.info("Alloc2 not ready")
            return
        self.log.info('id2 = %s' % (id))


class LoopSyncService(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Sync Service  create(service=', service._path, ')')
        pool_name = service.pool
        alloc_name = service.allocation_name if service.allocation_name else service.name
        sock = socket.socket()

        # Update 'deploys' oper data count
        cdb.connect(sock, type=cdb.DATA_SOCKET, ip='127.0.0.1', port=_ncs.NCS_PORT)
        cdb.start_session(sock, db=cdb.OPERATIONAL)
        deploy_path = "/services/id-loop-sync-python{{{}}}/deploys".format(service.name)
        deploys  = 1

        if cdb.exists(sock, deploy_path):
            deploys = cdb.get(sock, deploy_path).as_pyval()

        if cdb.exists(sock, service._path):
            cdb.set_elem(sock, str(deploys + 1), deploy_path)

        cdb.end_session(sock)
        cdb.close(sock)

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-sync-python[name='%s']" % (service.name),
                                tctx.username,
                                pool_name,
                                alloc_name,
                                False,
                                -1,"default",True,root)

        response = id_allocator.id_read(tctx.username, root,
                                  pool_name, alloc_name)
        
        if response:
            if "Exception" in response:
                self.log.info("get error1 ",response)
            else:            
                self.log.info('first id = %s' % (response))
            
            
        else:
             self.log.info("not processed")
        

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-sync-python[name='%s']" % (service.name),
                                tctx.username,
                                pool_name,
                                "specific_id",
                                False,
                                20,"default",True,root)

        response = id_allocator.id_read(tctx.username, root,
                                  pool_name, "specific_id")
        if response:
            if "Exception" in response:
                self.log.info("get error2 ",response)
            else:            
                self.log.info('second id = %s' % (response))
            
            
        else:
             self.log.info("not processed2")
        
class LoopSyncSyncService(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Sync Sync Service  create(service=', service._path, ')')
        pool_name = service.pool
        alloc_name = service.allocation_name if service.allocation_name else service.name
        sync = service.sync
        sock = socket.socket()

        # Update 'deploys' oper data count
        cdb.connect(sock, type=cdb.DATA_SOCKET, ip='127.0.0.1', port=_ncs.NCS_PORT)
        cdb.start_session(sock, db=cdb.OPERATIONAL)
        deploy_path = "/services/id-loop-python{{{}}}/deploys".format(service.name)
        deploys  = 1

        if cdb.exists(sock, deploy_path):
            deploys = cdb.get(sock, deploy_path).as_pyval()

        if cdb.exists(sock, service._path):
            cdb.set_elem(sock, str(deploys + 1), deploy_path)

        cdb.end_session(sock)
        cdb.close(sock)

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-sync-sync-python[name='%s']" % (service.name),
                                tctx.username,
                                pool_name,
                                alloc_name,
                                sync,
                                -1,"default",True,root)

        response = id_allocator.id_read(tctx.username, root,
                                  pool_name, alloc_name)
        
        if response:
            if "Exception" in response:
                self.log.info("get error1 ",response)
            else:            
                self.log.info('first id = %s' % (response))
            
            
        else:
             self.log.info("allocation request not processed yet")

class LoopSyncSyncService2(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('Sync Sync Service2  create(service=', service._path, ')')
        pool_name = service.pool
        alloc_name = service.allocation_name if service.allocation_name else service.name
        sync = service.sync
        sock = socket.socket()

        # Update 'deploys' oper data count
        cdb.connect(sock, type=cdb.DATA_SOCKET, ip='127.0.0.1', port=_ncs.NCS_PORT)
        cdb.start_session(sock, db=cdb.OPERATIONAL)
        deploy_path = "/services/id-loop-python{{{}}}/deploys".format(service.name)
        deploys  = 1

        if cdb.exists(sock, deploy_path):
            deploys = cdb.get(sock, deploy_path).as_pyval()

        if cdb.exists(sock, service._path):
            cdb.set_elem(sock, str(deploys + 1), deploy_path)

        cdb.end_session(sock)
        cdb.close(sock)

        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-sync-sync-python[name='%s']" % (service.name),
                                tctx.username,
                                "pool1",
                                alloc_name,
                                sync,
                                -1,"default",True,root)
        self.log.info("done allocation for pool1")
        id_allocator.id_request(service,
                                "/services/id-vl:id-loop-sync-sync-python[name='%s']" % (service.name),
                                tctx.username,
                                "pool2",
                                alloc_name,
                                sync,
                                -1,"default",True,root)
        
        self.log.info("done allocation for pool2")
        response = id_allocator.id_read(tctx.username, root,
                                  "pool1", alloc_name)
        
        if response:
            if "Exception" in response:
                self.log.info("get error1 ",response)
            else:            
                self.log.info('first id = %s' % (response))
            
            
        else:
             self.log.info("allocation request not processed yet")



class IdPoolCreateService(Service):
    @Service.create
    def cb_create(self, tctx, root, service, proplist):
        self.log.info('ID_POOL_CREATE_SERVICE 1: Service create(service=', service._path, ')')

        self.log.info("service = {}".format(dir(service)))
        self.log.info("id-pool-create-service name == {}".format(service.name))

        pool_name = service.pool

        idpool = root.ralloc__resource_pools.idalloc__id_pool
        idpool.create(pool_name)

        mypool = idpool[pool_name]
        mypool_range = mypool.range
        mypool_range.start = service.range.start
        mypool_range.end = service.range.end

        self.log.info('ID_POOL_CREATE_SERVICE: Finished.')

class Loop(ncs.application.Application):
    def setup(self):
        self.log.info('Loop RUNNING')
        self.register_service('id-loopspnt-python', LoopService)
        self.register_service('id-loopspnt-sync-python', LoopSyncService)
        self.register_service('id-loopspnt-sync-sync-python', LoopSyncSyncService)
        self.register_service('id-pool-create-python', IdPoolCreateService)

    def teardown(self):
        self.log.info('Loop FINISHED')
