package com.tailf.pkg.resourcemanager;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import com.tailf.conf.Conf;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfEnumeration;
import com.tailf.conf.ConfException;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfTag;
import com.tailf.conf.ConfValue;
import com.tailf.conf.ConfXMLParam;
import com.tailf.conf.ConfXMLParamValue;
import com.tailf.dp.DpActionTrans;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.annotations.ActionCallback;
import com.tailf.dp.proto.ActionCBType;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.pkg.idallocator.IdAllocator;
import com.tailf.pkg.ipaddressallocator.IPAddressAllocator;
import com.tailf.pkg.ipam.Allocation;
import com.tailf.pkg.ipam.Subnet;
import com.tailf.pkg.nsoutil.NSOTools;
import com.tailf.pkg.resourcemanager.namespaces.resourceAllocator;
import com.tailf.pkg.idallocator.namespaces.idAllocator;
import com.tailf.pkg.ipaddressallocator.namespaces.ipaddressAllocator; 
import com.tailf.pkg.idpool.exceptions.AllocationException;

public class SyncAllocAction {
    private static final Logger LOGGER = Logger.getLogger(SyncAllocAction.class);

    @ActionCallback(callPoint = "sync-alloc-action", callType = ActionCBType.ACTION)
    public ConfXMLParam[] syncAllocAction(DpActionTrans trans, ConfTag name, ConfObject[] kp,
        ConfXMLParam[] params) throws DpCallbackException, ResourceErrorException {
        LOGGER.debug("sync-alloc-action start");
        List<ConfXMLParam> results = new ArrayList<>();
        String pool = null;
        String allocId = null;
        try (Socket socket = new Socket("localhost", Conf.NCS_PORT)) {
            Map<String, String> paramMap = fetchParamValues(params);
            pool = paramMap.get(resourceAllocator._pool_);
            allocId = paramMap.get(resourceAllocator._allocid_);
            String user = paramMap.get(resourceAllocator._user_);
            int cidrmask = Integer.parseInt(paramMap.get(resourceAllocator._cidrmask_));
            boolean invertCidr = Boolean.parseBoolean(paramMap.get(resourceAllocator._invertcidr_));
            String owner = paramMap.get(resourceAllocator._owner_);
            String startIp = paramMap.get(resourceAllocator._subnetstartip_);
            boolean dryrun = Boolean.parseBoolean(paramMap.get(resourceAllocator._dryrun_));

            LOGGER.debug("pool = " + pool + ", allocId = " + allocId + ", user = " + user
                + ", cidrmask = " + cidrmask + ", dryrun = " + dryrun + ", owner = " + owner
                + ", invertCidr = " + invertCidr + ", startIp = " + startIp);

            Maapi maapi = new Maapi(socket);
            maapi.attach(trans.getTransaction(), 0, trans.getUserInfo().getUserId());
            // using same method to call allocation logic during sync flow [python api]
            Allocation allocSubnet = IPAddressAllocator.allocateSync(maapi, trans.getTransaction(),
                pool, allocId, user, cidrmask, invertCidr, startIp, owner, dryrun);

            Subnet net = allocSubnet.getAllocated();
            Subnet fromNet = null;

            for (Subnet sub : IPAddressAllocator.getPool(pool).subnets) {
                if (sub.contains(net)) {
                    fromNet = sub;
                    break;
                }
            }
            // Update the action result as per the response
            if (null != net) {
                results.add(new ConfXMLParamValue(new resourceAllocator(),
                    resourceAllocator._allocated_, new ConfBuf(net.toString())));
            } else {
                results.add(new ConfXMLParamValue(new resourceAllocator(),
                    resourceAllocator._allocated_, new ConfBuf("")));
            }
            if (null != fromNet) {
                results.add(new ConfXMLParamValue(new resourceAllocator(),
                    resourceAllocator._subnet_, new ConfBuf(fromNet.toString())));
            } else {
                results.add(new ConfXMLParamValue(new resourceAllocator(),
                    resourceAllocator._subnet_, new ConfBuf("")));
            }
            LOGGER.debug("sync-alloc-action done allocated: " + net + ", subnet: " + fromNet);
        } catch (Exception ex) {
            String errMsg = "Error while allocating ip-address from pool: " + pool
                + ", with allocation-id: " + allocId + ". ";
            results.add(new ConfXMLParamValue(new resourceAllocator(),
                resourceAllocator._allocated_, new ConfBuf(errMsg + ex.getMessage())));
            LOGGER.error(errMsg, ex);
        }
        return results.toArray(new ConfXMLParam[results.size()]);
    }

    
    @SuppressWarnings("deprecation")
    @ActionCallback(callPoint = "sync-alloc-id-action", callType = ActionCBType.ACTION)
    public ConfXMLParam[] syncAllocIdAction(DpActionTrans trans, ConfTag name, ConfObject[] kp,
        ConfXMLParam[] params) throws DpCallbackException, ResourceErrorException {
        LOGGER.debug("sync-alloc-id-action start");
        List<ConfXMLParam> results = new ArrayList<>();
        String pool = null;
        String allocId = null;
        try (Socket socket = new Socket("localhost", Conf.NCS_PORT)) {
            Map<String, String> paramMap = fetchParamValues(params);
            pool = paramMap.get(resourceAllocator._pool_);
            allocId = paramMap.get(resourceAllocator._allocid_);
            String user = paramMap.get(resourceAllocator._user_);
            String owner = paramMap.get(resourceAllocator._owner_);
            long requestedId = Long.parseLong(paramMap.get(resourceAllocator._requestedId_));
            String method = paramMap.get(resourceAllocator._method_);
            boolean dryrun = Boolean.parseBoolean(paramMap.get(resourceAllocator._dryrun_));
            boolean sync = Boolean.parseBoolean(paramMap.get(resourceAllocator._sync_));

            LOGGER.debug("pool = " + pool + ", allocId = " + allocId + ", user = " + user
                + ", dryrun = " + dryrun + ", owner = " + owner +"  method = "+method + "  sync = " + sync
                );
            
            Maapi maapi = new Maapi(socket);
            maapi.attach(trans.getTransaction(), 0, trans.getUserInfo().getUserId());

            com.tailf.pkg.idpool.Allocation  allocation = IdAllocator.allocateIdSync(maapi, trans.getTransaction(),
                    pool, allocId, user, owner,requestedId,method, dryrun,sync);

         
             String allocatedId  = String.valueOf(allocation.getAllocated());
             results.add(new ConfXMLParamValue(new resourceAllocator(),
                        resourceAllocator._allocatedId_, new ConfBuf(allocatedId)));
           
            
            LOGGER.debug("sync-alloc-id-action done allocated: " + allocation.getAllocated());
        } catch (Exception ex) {
            String errMsg = "Error while allocating id from pool: " + pool
                    + ", with allocation-id: " + allocId + ". ";
            results.add(new ConfXMLParamValue(new resourceAllocator(),
                    resourceAllocator._allocatedId_,  new ConfBuf(ex.toString())));
            LOGGER.error(errMsg, ex);
        }
        return results.toArray(new ConfXMLParam[results.size()]);
    }



    public static Map<String, String> fetchParamValues(ConfXMLParam[] params) throws ConfException {
        HashMap<String, String> paramVals = new HashMap<>();
        for (ConfXMLParam param : params) {
            String val = "";        
            ConfValue value = (ConfValue)param.getValue();
            if(value != null && param.getTag().equals("operation") && value instanceof ConfEnumeration) {
            	
            	String path = param.getNSHash() == idAllocator.hash ?
            		"/ralloc:rm-action/idalloc:id-allocator-tool/operation" :
            		"/ralloc:rm-action/ipalloc:ip-allocator-tool/operation";
            	
            	val =  ConfValue.getStringByValue(path, value);
            			
            }else {
            	val = value!= null && !value.toString().isEmpty()
                        ? value.toString()
                        : val;
            }
                
                
            paramVals.put(param.getTag(), val);
        }
        return paramVals;
    }
    
    @SuppressWarnings("deprecation")
    @ActionCallback(callPoint = "id-allocator-tool-action", callType = ActionCBType.ACTION)
    public ConfXMLParam[] idAllocatorToolAction(DpActionTrans trans, ConfTag name, ConfObject[] kp,
        ConfXMLParam[] params) throws ResourceErrorException, ConfException, IOException, AllocationException {
        LOGGER.info("-------------id-allocator-tool-action start");
        String resultString = "Done!";
        Map<String, String> paramMap = fetchParamValues(params);
        

        String pool = paramMap.get("pool");
        String operation = paramMap.get("operation");
        LOGGER.info("[action] pool = " + pool +  "    operation = " + operation);
        if(operation.equals("printIdPool")) {
        	for (IdAllocator.Pool p: IdAllocator.pools ) {
        		if(pool==null || p.idPool.getName().equals(pool) ){
        			LOGGER.info("idPool = "+ p.idPool.getName() + "   available = " + p.idPool.getAvailables());
        			for(com.tailf.pkg.idpool.Allocation a: p.idPool.getAllocations()) {
        				LOGGER.info("allocation = "+a);
        			}
        		}
        	}
        } else if(operation.equals("check_missing_report") || operation.startsWith("fix_missing")) {
             	Socket socket = new Socket("localhost", Conf.NCS_PORT);                         
                Maapi maapi = new Maapi(socket);
                maapi.startUserSession("admin",
                	     InetAddress.getByName("localhost"),
                	     "maapi",
                	     new String[] { "admin" },
                	     MaapiUserSessionFlag.PROTO_TCP);
                int tid = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);              
                NSOTools.checkAllAllocations(maapi,tid,pool,operation);
                LOGGER.debug(operation + " end.");                         
        	
        }else if(operation.equals("fix_response_id")) {
        	
             if(pool!=null) {
            	 NSOTools.checkSyncAllocations(pool);
             }else {
            	 resultString = "Please pick an idPool.";
             }
             
             
        }else if(operation.equals("persistAll")) {

           	NSOTools.persistAll(pool);
           
       }else {
    	   LOGGER.error("unknow operation");
    	   resultString = "unknow operation";
       }
      
        return new ConfXMLParam[] {new ConfXMLParamValue(new idAllocator(),
        		"result",
        		new ConfBuf(resultString))};
        
    }
    
    @SuppressWarnings("deprecation")
    @ActionCallback(callPoint = "ip-allocator-tool-action", callType = ActionCBType.ACTION)
    public ConfXMLParam[] ipAllocatorToolAction(DpActionTrans trans, ConfTag name, ConfObject[] kp,
        ConfXMLParam[] params) throws ResourceErrorException, ConfException, IOException, AllocationException {
        LOGGER.info("-------------ip-allocator-tool-action start");
        String resultString = "Done!";
        Map<String, String> paramMap = fetchParamValues(params);

        String pool = paramMap.get("pool");
        String operation = paramMap.get("operation");
        LOGGER.info("[action] pool = " + pool +  "    operation = " + operation);
        if(operation.equals("printIpPool")) {
        	for (IPAddressAllocator.Pool p: IPAddressAllocator.pools ) {
        		if(pool==null || p.ipPool.getName().equals(pool) ){
        			LOGGER.info("ipPool = "+ p.ipPool.getName() + "   available = " + p.ipPool.getAvailables(false));
        			for(com.tailf.pkg.ipam.Allocation a: p.ipPool.getAllocations(false)) {
        				LOGGER.info("allocation = "+a);
        			}
        		}
        	}
        }else if(operation.equals("fix_response_ip")) {
        	if(pool!=null) {
           	 	NSOTools.checkIpSyncAllocations(pool);
            }else {
           	 	resultString = "Please pick an idPool.";
            }
            
        	
        }
        else {
    	   LOGGER.error("unknow operation");
    	   resultString = "unknow operation";
       }
      
        return new ConfXMLParam[] {new ConfXMLParamValue(new ipaddressAllocator(),
        		"result",
        		new ConfBuf(resultString))};
        
    }

}
